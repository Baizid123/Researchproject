import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/stat-card";
import { DataTable } from "@/components/data-table";
import { CodeViewer } from "@/components/code-viewer";
import { Skeleton } from "@/components/ui/skeleton";
import { Database, Film, Star, CheckCircle, AlertTriangle } from "lucide-react";
import type { PreprocessingStats, Movie } from "@shared/schema";

const preprocessingCode = `# Data Preprocessing Pipeline
import pandas as pd
import numpy as np

# Load the dataset
df = pd.read_csv('movies.csv')
print(f"Loaded {len(df)} movies")

# Display basic info
print("\\nDataset Shape:", df.shape)
print("\\nColumn Types:")
print(df.dtypes)

# Handle missing values
def clean_data(df):
    # Fill missing overviews with empty string
    df['overview'] = df['overview'].fillna('')
    
    # Fill missing genres
    df['genres'] = df['genres'].fillna('')
    
    # Fill numeric columns with median
    numeric_cols = ['budget', 'revenue', 'runtime', 'vote_average']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = df[col].fillna(df[col].median())
    
    return df

df = clean_data(df)

# Create combined text feature for TF-IDF
df['combined'] = (
    df['title'].astype(str) + ' ' + 
    df['genres'].str.replace('|', ' ') + ' ' + 
    df['overview'].astype(str) + ' ' +
    df['keywords'].astype(str).str.replace('|', ' ')
)

# Data quality metrics
missing_pct = (df.isnull().sum() / len(df) * 100).round(2)
print("\\nMissing Values (%):")
print(missing_pct)

print("\\nPreprocessing complete!")`;

export function PreprocessingTab() {
  const { data: stats, isLoading, error } = useQuery<PreprocessingStats>({
    queryKey: ["/api/preprocessing"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6" data-testid="preprocessing-loading">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-4 w-24 mb-2" />
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Card>
          <CardContent className="p-6">
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <p className="text-lg font-medium">Failed to load preprocessing data</p>
          <p className="text-sm text-muted-foreground mt-2">
            Please check the server connection and try again.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (!stats) return null;

  const tableColumns = ["index", "title", "genres", "vote_average", "popularity", "runtime"];
  const tableData = stats.sampleData.map((movie) => ({
    index: movie.index,
    title: movie.title,
    genres: movie.genres?.replace(/\s+/g, ", ") || "-",
    vote_average: movie.vote_average,
    popularity: movie.popularity?.toFixed(2),
    runtime: movie.runtime ? `${movie.runtime} min` : "-",
  }));

  const missingValueData = Object.entries(stats.missingValues || {})
    .map(([column, count]) => ({
      column,
      missing: count,
      percentage: ((count / stats.totalMovies) * 100).toFixed(2) + "%",
    }))
    .filter((d) => d.missing > 0);

  return (
    <div className="space-y-6" data-testid="preprocessing-content">
      <div>
        <h2 className="text-2xl font-semibold mb-2">Data Pre-processing</h2>
        <p className="text-muted-foreground">
          Preview and basic cleaning performed on the movie dataset automatically.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Movies"
          value={stats.totalMovies.toLocaleString()}
          icon={Database}
          description="Records in dataset"
        />
        <StatCard
          title="Unique Genres"
          value={stats.uniqueGenres}
          icon={Film}
          description="Distinct categories"
        />
        <StatCard
          title="Avg Rating"
          value={stats.avgRating.toFixed(2)}
          icon={Star}
          description="Mean vote average"
        />
        <StatCard
          title="Data Quality"
          value={`${stats.dataQuality.toFixed(1)}%`}
          icon={CheckCircle}
          description="Non-null values"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <DataTable
            title="Dataset Preview"
            data={tableData}
            columns={tableColumns}
            pageSize={10}
          />
        </div>
        <div className="space-y-4">
          <Card>
            <CardHeader className="py-4">
              <CardTitle className="text-lg">Missing Values</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {missingValueData.length > 0 ? (
                missingValueData.slice(0, 8).map((item) => (
                  <div key={item.column} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="truncate">{item.column}</span>
                      <span className="text-muted-foreground">{item.percentage}</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-destructive/80 rounded-full"
                        style={{ width: item.percentage }}
                      />
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4 text-muted-foreground">
                  <CheckCircle className="h-8 w-8 mx-auto mb-2 text-green-500" />
                  <p className="text-sm">No significant missing values</p>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="py-4">
              <CardTitle className="text-lg">Column Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {Object.entries(stats.columnTypes || {}).slice(0, 8).map(([col, type]) => (
                  <div key={col} className="flex justify-between text-sm">
                    <span className="truncate text-muted-foreground">{col}</span>
                    <code className="text-xs bg-muted px-2 py-0.5 rounded">{type}</code>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <CodeViewer
        title="Preprocessing Pipeline Code"
        code={preprocessingCode}
        language="python"
        defaultOpen={false}
      />
    </div>
  );
}
