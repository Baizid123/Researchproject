import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/stat-card";
import { CodeViewer } from "@/components/code-viewer";
import { Skeleton } from "@/components/ui/skeleton";
import { Layers, Hash, FileText, Cpu, AlertTriangle } from "lucide-react";
import type { FeatureEngineering } from "@shared/schema";

const featureEngineeringCode = `# Feature Engineering - TF-IDF Vectorization
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize
import numpy as np

# Initialize TF-IDF Vectorizer
vectorizer = TfidfVectorizer(
    max_features=20000,       # Limit vocabulary size
    stop_words='english',     # Remove common words
    ngram_range=(1, 2),       # Use unigrams and bigrams
    min_df=2,                 # Minimum document frequency
    max_df=0.95,              # Maximum document frequency
    sublinear_tf=True         # Apply sublinear tf scaling
)

# Fit and transform the combined text
print("Fitting TF-IDF vectorizer...")
tfidf_matrix = vectorizer.fit_transform(df['combined'])

print(f"TF-IDF Matrix Shape: {tfidf_matrix.shape}")
print(f"Vocabulary Size: {len(vectorizer.vocabulary_)}")

# Get feature names (terms)
feature_names = vectorizer.get_feature_names_out()

# Calculate term importance (sum of TF-IDF scores)
term_scores = np.array(tfidf_matrix.sum(axis=0)).flatten()
top_indices = term_scores.argsort()[-20:][::-1]

print("\\nTop 20 Terms by TF-IDF Weight:")
for i, idx in enumerate(top_indices):
    print(f"{i+1}. {feature_names[idx]}: {term_scores[idx]:.4f}")

# Normalize the TF-IDF matrix for cosine similarity
tfidf_normalized = normalize(tfidf_matrix, norm='l2')

print("\\nFeature engineering complete!")
print(f"Matrix is normalized and ready for similarity computation.")`;

export function FeatureEngineeringTab() {
  const { data: features, isLoading, error } = useQuery<FeatureEngineering>({
    queryKey: ["/api/features"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6" data-testid="features-loading">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-4 w-24 mb-2" />
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Card>
          <CardContent className="p-6">
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <p className="text-lg font-medium">Failed to load feature engineering data</p>
          <p className="text-sm text-muted-foreground mt-2">
            Please check the server connection and try again.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (!features) return null;

  return (
    <div className="space-y-6" data-testid="features-content">
      <div>
        <h2 className="text-2xl font-semibold mb-2">Feature Engineering</h2>
        <p className="text-muted-foreground">
          TF-IDF vectors computed from combined movie text (title + genres + overview + keywords).
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="TF-IDF Rows"
          value={features.tfidfShape[0].toLocaleString()}
          icon={Layers}
          description="Movies processed"
        />
        <StatCard
          title="TF-IDF Columns"
          value={features.tfidfShape[1].toLocaleString()}
          icon={Hash}
          description="Feature dimensions"
        />
        <StatCard
          title="Vocabulary Size"
          value={features.vocabularySize.toLocaleString()}
          icon={FileText}
          description="Unique terms"
        />
        <StatCard
          title="Movies Processed"
          value={features.processedMovies.toLocaleString()}
          icon={Cpu}
          description="Successfully vectorized"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Top Features by TF-IDF Weight</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {features.topFeatures.slice(0, 15).map((feature, i) => (
                <div key={feature.term} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">
                      <span className="text-muted-foreground mr-2">{i + 1}.</span>
                      {feature.term}
                    </span>
                    <span className="text-muted-foreground font-mono text-xs">
                      {feature.weight.toFixed(4)}
                    </span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all duration-500"
                      style={{
                        width: `${(feature.weight / features.topFeatures[0].weight) * 100}%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">TF-IDF Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">Max Features</p>
                <p className="text-xl font-semibold">20,000</p>
              </div>
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">N-gram Range</p>
                <p className="text-xl font-semibold">(1, 2)</p>
              </div>
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">Min Doc Freq</p>
                <p className="text-xl font-semibold">2</p>
              </div>
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">Max Doc Freq</p>
                <p className="text-xl font-semibold">95%</p>
              </div>
            </div>
            
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">Text Sources</p>
              <div className="flex flex-wrap gap-2">
                {["Title", "Genres", "Overview", "Keywords", "Cast", "Director"].map((source) => (
                  <span
                    key={source}
                    className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium"
                  >
                    {source}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">Preprocessing Steps</p>
              <ul className="text-sm space-y-1">
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-primary rounded-full" />
                  Lowercase conversion
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-primary rounded-full" />
                  Stop words removal
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-primary rounded-full" />
                  Sublinear TF scaling
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-primary rounded-full" />
                  L2 normalization
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>

      <CodeViewer
        title="Feature Engineering Code"
        code={features.codeOutput || featureEngineeringCode}
        language="python"
        defaultOpen={false}
      />
    </div>
  );
}
