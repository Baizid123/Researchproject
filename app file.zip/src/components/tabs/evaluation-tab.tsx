import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  CheckCircle,
  Search,
  Sparkles,
  Info,
  BrainCircuit,
  FileText,
  Zap,
  Users,
  MessageSquare,
  Layers,
  Target,
  Clock,
  Shield,
  BookOpen,
} from "lucide-react";

export function EvaluationTab() {
  return (
    <div className="space-y-6" data-testid="evaluation-content">
      <div>
        <h2 className="text-2xl font-semibold mb-2">Qualitative Evaluation</h2>
        <p className="text-muted-foreground">
          Offline and qualitative analysis of Content-Based (TF-IDF) vs Hybrid with AI recommendation methods.
        </p>
      </div>

      <Card className="bg-amber-500/5 border-amber-500/20">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-sm">Evaluation Approach</p>
              <p className="text-sm text-muted-foreground mt-1">
                Evaluation at this stage is conducted through functional testing and qualitative assessment, 
                focusing on recommendation relevance, semantic coherence, and consistency across different 
                recommendation modes. Quantitative metrics (precision, recall, F1) would require user studies 
                with ground truth data, which is outside the scope of this offline analysis.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 h-auto p-1">
          <TabsTrigger value="overview" className="py-2.5" data-testid="eval-subtab-overview">
            Method Overview
          </TabsTrigger>
          <TabsTrigger value="criteria" className="py-2.5" data-testid="eval-subtab-criteria">
            Evaluation Criteria
          </TabsTrigger>
          <TabsTrigger value="comparison" className="py-2.5" data-testid="eval-subtab-comparison">
            Qualitative Comparison
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gradient-to-br from-blue-600/5 to-transparent border-blue-600/20">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Search className="w-5 h-5 text-blue-700 dark:text-blue-400" />
                  Content-Based (TF-IDF)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Pure text similarity using TF-IDF vectorization of movie descriptions, keywords, cast, and crew.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-blue-600/10 text-blue-700 dark:text-blue-400 border-blue-600/30">
                      <FileText className="w-3 h-3 mr-1" />
                      Text Similarity
                    </Badge>
                    <Badge variant="outline" className="bg-blue-600/10 text-blue-700 dark:text-blue-400 border-blue-600/30">
                      <Zap className="w-3 h-3 mr-1" />
                      Fast
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Recommendations based on cosine similarity of TF-IDF vectors from combined movie features.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-emerald-600/5 to-transparent border-emerald-600/20">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <BrainCircuit className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  Hybrid with AI
                  <Badge variant="secondary" className="text-xs">Enhanced</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Multi-signal scoring with Gemini AI for contextual understanding and personalized explanations.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className="bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 border-emerald-600/30">
                      <Layers className="w-3 h-3 mr-1" />
                      Multi-Signal
                    </Badge>
                    <Badge variant="outline" className="bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 border-emerald-600/30">
                      <MessageSquare className="w-3 h-3 mr-1" />
                      NLU
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    TF-IDF (40%) + Genre (30%) + Rating (20%) + Popularity (10%) + Gemini contextual re-ranking.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                Hybrid Framework Components
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-lg bg-blue-600/5 border border-blue-600/20 text-center">
                  <p className="text-2xl font-bold text-blue-700 dark:text-blue-400">40%</p>
                  <p className="text-sm text-muted-foreground mt-1">TF-IDF Similarity</p>
                  <p className="text-xs text-muted-foreground">Content matching</p>
                </div>
                <div className="p-4 rounded-lg bg-indigo-600/5 border border-indigo-600/20 text-center">
                  <p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">30%</p>
                  <p className="text-sm text-muted-foreground mt-1">Genre Overlap</p>
                  <p className="text-xs text-muted-foreground">Category matching</p>
                </div>
                <div className="p-4 rounded-lg bg-amber-600/5 border border-amber-600/20 text-center">
                  <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">20%</p>
                  <p className="text-sm text-muted-foreground mt-1">Rating Quality</p>
                  <p className="text-xs text-muted-foreground">User ratings</p>
                </div>
                <div className="p-4 rounded-lg bg-emerald-600/5 border border-emerald-600/20 text-center">
                  <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">10%</p>
                  <p className="text-sm text-muted-foreground mt-1">Popularity</p>
                  <p className="text-xs text-muted-foreground">Vote count signal</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground text-center mt-4">
                Gemini AI provides contextual re-ranking and personalized explanations on top of the hybrid scoring
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="criteria" className="space-y-6">
          <Card className="bg-muted/30">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <BookOpen className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-sm">Qualitative Evaluation Criteria</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    The following criteria are used to assess recommendation quality through manual inspection 
                    and functional testing, rather than automated quantitative metrics.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Target className="w-4 h-4 text-blue-700 dark:text-blue-400" />
                  Recommendation Relevance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Do recommended movies align with the input query or seed movie characteristics?
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Genre alignment with seed movie</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Thematic similarity in plot/overview</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>User intent understanding (for AI)</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  Semantic Coherence
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Are the AI-generated explanations meaningful and accurate?
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Explanation matches movie attributes</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Rationale connects to user query</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>No hallucinated movie details</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Shield className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  Consistency
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Are results stable across different modes and similar queries?
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Similar inputs yield similar outputs</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Stable across recommendation modes</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Reproducible similarity scores</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Layers className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  Diversity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Do recommendations offer variety beyond obvious choices?
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Mix of popular and niche titles</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Release year distribution</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Not just franchise sequels</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Clock className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                  Response Quality
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  System responsiveness and output completeness.
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Reasonable response time</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Complete data fields returned</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Graceful error handling</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                  Explainability
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Can users understand why movies were recommended?
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Similarity scores provided</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>AI explanations for hybrid mode</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span>Transparent recommendation logic</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="comparison" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Search className="w-4 h-4 text-blue-700 dark:text-blue-400" />
                  Content-Based (TF-IDF) Characteristics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="font-medium text-sm mb-2 text-emerald-600 dark:text-emerald-400">Strengths</p>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>Fast computation with pre-built TF-IDF matrix</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>No cold-start problem for new users</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>Explainable based on text feature similarity</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>Works well for plot-based similarity queries</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>Deterministic and reproducible results</span>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium text-sm mb-2 text-amber-600 dark:text-amber-400">Limitations</p>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                        <span>Limited to text-based features only</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                        <span>Cannot understand nuanced user intent</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                        <span>May miss semantic relationships</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <BrainCircuit className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  Hybrid with AI Characteristics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="font-medium text-sm mb-2 text-emerald-600 dark:text-emerald-400">Strengths</p>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>Natural language intent understanding via Gemini</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>Personalized explanations for each recommendation</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>Multi-signal scoring (content + genre + rating + popularity)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>Context-aware re-ranking for better relevance</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>Can handle complex, nuanced queries</span>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium text-sm mb-2 text-amber-600 dark:text-amber-400">Limitations</p>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                        <span>Slower response time (API calls)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                        <span>Depends on external AI service availability</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                        <span>Non-deterministic outputs from LLM</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Use Case Recommendations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 font-semibold">Use Case</th>
                      <th className="text-center py-3 px-4 font-semibold">Content-Based</th>
                      <th className="text-center py-3 px-4 font-semibold">Hybrid with AI</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-border">
                      <td className="py-3 px-4">Find movies similar to a specific title</td>
                      <td className="text-center py-3 px-4">
                        <Badge className="bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 border-emerald-600/30">Recommended</Badge>
                      </td>
                      <td className="text-center py-3 px-4">
                        <Badge variant="outline">Good</Badge>
                      </td>
                    </tr>
                    <tr className="border-b border-border">
                      <td className="py-3 px-4">Natural language movie requests</td>
                      <td className="text-center py-3 px-4">
                        <Badge variant="outline">Limited</Badge>
                      </td>
                      <td className="text-center py-3 px-4">
                        <Badge className="bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 border-emerald-600/30">Recommended</Badge>
                      </td>
                    </tr>
                    <tr className="border-b border-border">
                      <td className="py-3 px-4">Genre-based exploration</td>
                      <td className="text-center py-3 px-4">
                        <Badge variant="outline">Good</Badge>
                      </td>
                      <td className="text-center py-3 px-4">
                        <Badge className="bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 border-emerald-600/30">Recommended</Badge>
                      </td>
                    </tr>
                    <tr className="border-b border-border">
                      <td className="py-3 px-4">Fast, real-time recommendations</td>
                      <td className="text-center py-3 px-4">
                        <Badge className="bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 border-emerald-600/30">Recommended</Badge>
                      </td>
                      <td className="text-center py-3 px-4">
                        <Badge variant="outline">Slower</Badge>
                      </td>
                    </tr>
                    <tr className="border-b border-border">
                      <td className="py-3 px-4">Mood-based suggestions</td>
                      <td className="text-center py-3 px-4">
                        <Badge variant="outline">Limited</Badge>
                      </td>
                      <td className="text-center py-3 px-4">
                        <Badge className="bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 border-emerald-600/30">Recommended</Badge>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4">Explainable recommendations</td>
                      <td className="text-center py-3 px-4">
                        <Badge variant="outline">Similarity scores</Badge>
                      </td>
                      <td className="text-center py-3 px-4">
                        <Badge className="bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 border-emerald-600/30">Natural language</Badge>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-muted/30">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-sm">Future Work: Quantitative Evaluation</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    To compute standard recommendation metrics (Precision@K, Recall@K, NDCG, MAP), 
                    a user study with explicit relevance judgments or implicit feedback data would be required. 
                    This would enable A/B testing between the two methods with statistical significance.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
