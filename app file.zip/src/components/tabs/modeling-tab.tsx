import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MovieCard } from "@/components/movie-card";
import { CodeViewer } from "@/components/code-viewer";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Loader2, Cpu, Clock, AlertTriangle, X, Film } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import type { ContentBasedResult, Movie } from "@shared/schema";

const modelingCode = `# Content-Based Recommendation Model
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

# Initialize k-NN model with cosine distance
knn_model = NearestNeighbors(
    metric='cosine',
    algorithm='brute',
    n_neighbors=20
)

# Fit the model on TF-IDF matrix
knn_model.fit(tfidf_normalized)

def get_recommendations(movie_title, n=6):
    """Get content-based recommendations for a movie."""
    # Find the movie index
    idx = df[df['title'] == movie_title].index[0]
    
    # Get k nearest neighbors
    distances, indices = knn_model.kneighbors(
        tfidf_normalized[idx], 
        n_neighbors=n+1
    )
    
    # Convert distances to similarities
    similarities = 1 - distances[0]
    
    # Get recommended movies (excluding the input movie)
    recommendations = []
    for i, sim_idx in enumerate(indices[0][1:]):
        movie = df.iloc[sim_idx]
        recommendations.append({
            'title': movie['title'],
            'genres': movie['genres'],
            'similarity': similarities[i+1],
            'overview': movie['overview'],
            'vote_average': movie['vote_average']
        })
    
    return recommendations

# Example usage
recs = get_recommendations("Avatar", n=6)
for rec in recs:
    print(f"{rec['title']} - Similarity: {rec['similarity']:.4f}")`;

export function ModelingTab() {
  const [selectedMovie, setSelectedMovie] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [showDropdown, setShowDropdown] = useState(false);
  const [numRecs, setNumRecs] = useState<number>(6);
  const [method, setMethod] = useState<"tfidf" | "hybrid">("tfidf");

  const { data: movies, isLoading: moviesLoading } = useQuery<Movie[]>({
    queryKey: ["/api/movies"],
  });

  const recommendMutation = useMutation<ContentBasedResult, Error, { movieTitle: string; numRecommendations: number; method: string }>({
    mutationFn: async (params) => {
      const res = await apiRequest("POST", "/api/recommendations/content", params);
      return res.json();
    },
  });

  const filteredMovies = useMemo(() => {
    if (!movies || !searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    return movies.filter((m) => m.title.toLowerCase().includes(query)).slice(0, 10);
  }, [movies, searchQuery]);

  const handleGetRecommendations = () => {
    if (!selectedMovie) return;
    recommendMutation.mutate({
      movieTitle: selectedMovie,
      numRecommendations: numRecs,
      method,
    });
  };

  const handleSelectMovie = (title: string) => {
    setSelectedMovie(title);
    setSearchQuery(title);
    setShowDropdown(false);
  };

  const handleClearSelection = () => {
    setSelectedMovie("");
    setSearchQuery("");
  };

  return (
    <div className="space-y-6" data-testid="modeling-content">
      <div>
        <h2 className="text-2xl font-semibold mb-2">Modeling: Content-Based Recommendations</h2>
        <p className="text-muted-foreground">
          Search for similar movies using TF-IDF similarity scoring.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Configure Recommendation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <Label htmlFor="movie-search">Search for a Movie</Label>
              <div className="relative">
                <div className="relative flex items-center">
                  <Search className="absolute left-3 w-4 h-4 text-muted-foreground pointer-events-none" />
                  <Input
                    id="movie-search"
                    placeholder="Type to search movies..."
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setShowDropdown(true);
                      if (e.target.value !== selectedMovie) {
                        setSelectedMovie("");
                      }
                    }}
                    onFocus={() => setShowDropdown(true)}
                    className="pl-9 pr-9"
                    disabled={moviesLoading}
                    data-testid="input-movie-search"
                  />
                  {searchQuery && (
                    <button
                      onClick={handleClearSelection}
                      className="absolute right-3 text-muted-foreground"
                      data-testid="button-clear-search"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
                {showDropdown && filteredMovies.length > 0 && !selectedMovie && (
                  <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-md shadow-lg max-h-60 overflow-auto">
                    {filteredMovies.map((movie) => (
                      <button
                        key={movie.id}
                        onClick={() => handleSelectMovie(movie.title)}
                        className="w-full px-3 py-2 text-left text-sm hover-elevate flex items-center gap-2"
                        data-testid={`option-movie-${movie.id}`}
                      >
                        <Film className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                        <span className="truncate">{movie.title}</span>
                        {movie.release_date && (
                          <span className="text-xs text-muted-foreground ml-auto">({movie.release_date.slice(0, 4)})</span>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {selectedMovie && (
                <p className="text-sm text-muted-foreground">Selected: {selectedMovie}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="method-select">Method</Label>
              <Select value={method} onValueChange={(v) => setMethod(v as "tfidf" | "hybrid")}>
                <SelectTrigger id="method-select" data-testid="select-method">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tfidf">TF-IDF Similarity</SelectItem>
                  <SelectItem value="hybrid">Hybrid (TF-IDF + Metadata)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Number of Recommendations: {numRecs}</Label>
              <Slider
                value={[numRecs]}
                onValueChange={([v]) => setNumRecs(v)}
                min={3}
                max={12}
                step={1}
                className="mt-3"
                data-testid="slider-num-recs"
              />
            </div>
          </div>

          <Button
            onClick={handleGetRecommendations}
            disabled={!selectedMovie || recommendMutation.isPending}
            className="w-full md:w-auto"
            data-testid="button-get-recommendations"
          >
            {recommendMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Finding Similar Movies...
              </>
            ) : (
              <>
                <Search className="w-4 h-4 mr-2" />
                Get Recommendations
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {recommendMutation.isPending && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: numRecs }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <Skeleton className="w-20 h-28 rounded-lg" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-5 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-2/3" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {recommendMutation.isError && (
        <Card>
          <CardContent className="p-8 text-center">
            <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <p className="text-lg font-medium">Failed to get recommendations</p>
            <p className="text-sm text-muted-foreground mt-2">
              {recommendMutation.error?.message || "Please try again."}
            </p>
          </CardContent>
        </Card>
      )}

      {recommendMutation.isSuccess && recommendMutation.data && (
        <>
          <div className="flex items-center gap-6 flex-wrap">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Cpu className="w-4 h-4" />
              <span>Method: {recommendMutation.data.method.toUpperCase()}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>Processing time: {recommendMutation.data.processingTime.toFixed(0)}ms</span>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">
              Movies similar to "{recommendMutation.data.inputMovie}"
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {recommendMutation.data.recommendations.map((movie, i) => (
                <MovieCard key={movie.title} movie={movie} index={i} />
              ))}
            </div>
          </div>
        </>
      )}

      <CodeViewer
        title="Content-Based Model Code"
        code={recommendMutation.data?.codeOutput || modelingCode}
        language="python"
        defaultOpen={false}
      />
    </div>
  );
}
