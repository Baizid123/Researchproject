import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, Loader2, Clock, Cpu, AlertTriangle, Star, Film } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { GenAIResult } from "@shared/schema";

const GENRE_OPTIONS = [
  "Action", "Adventure", "Animation", "Comedy", "Crime", 
  "Documentary", "Drama", "Family", "Fantasy", "History",
  "Horror", "Music", "Mystery", "Romance", "Science Fiction",
  "Thriller", "War", "Western"
];

export function GenAITab() {
  const { toast } = useToast();
  const [userQuery, setUserQuery] = useState("");
  const [preferredGenres, setPreferredGenres] = useState<string[]>([]);
  const [numRecs, setNumRecs] = useState<number>(5);

  const recommendMutation = useMutation<GenAIResult, Error, { userQuery: string; likedMovies: string[]; dislikedMovies: string[]; preferredGenres: string[]; numRecommendations?: number }>({
    mutationFn: async (params) => {
      const res = await apiRequest("POST", "/api/recommendations/genai", params);
      return res.json();
    },
    onError: (error) => {
      toast({
        title: "AI Recommendation Failed",
        description: error.message || "Could not get AI recommendations. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleToggleGenre = (genre: string) => {
    if (preferredGenres.includes(genre)) {
      setPreferredGenres(preferredGenres.filter((g) => g !== genre));
    } else {
      setPreferredGenres([...preferredGenres, genre]);
    }
  };

  const handleGetRecommendations = () => {
    recommendMutation.mutate({
      userQuery,
      likedMovies: [],
      dislikedMovies: [],
      preferredGenres,
      numRecommendations: numRecs,
    });
  };

  return (
    <div className="space-y-6" data-testid="genai-content">
      <div>
        <h2 className="text-2xl font-semibold mb-2">AI Movie Recommendations</h2>
        <p className="text-muted-foreground">
          Get personalized movie suggestions powered by Gemini AI based on your mood and preferences.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader className="py-4">
              <CardTitle className="text-lg flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                Your Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>What are you in the mood for?</Label>
                <Textarea
                  placeholder="e.g., A thrilling action movie with great plot twists, or a heartwarming comedy for family night..."
                  value={userQuery}
                  onChange={(e) => setUserQuery(e.target.value)}
                  className="min-h-28"
                  data-testid="input-user-query"
                />
              </div>

              <div className="space-y-2">
                <Label>Preferred Genres</Label>
                <div className="flex flex-wrap gap-2">
                  {GENRE_OPTIONS.map((genre) => (
                    <Badge
                      key={genre}
                      variant={preferredGenres.includes(genre) ? "default" : "outline"}
                      className="cursor-pointer toggle-elevate"
                      onClick={() => handleToggleGenre(genre)}
                      data-testid={`badge-genre-${genre.toLowerCase().replace(' ', '-')}`}
                    >
                      {genre}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <Label>Number of Recommendations: {numRecs}</Label>
                <Slider
                  value={[numRecs]}
                  onValueChange={([v]) => setNumRecs(v)}
                  min={3}
                  max={10}
                  step={1}
                  data-testid="slider-num-ai-recs"
                />
              </div>

              <Button
                onClick={handleGetRecommendations}
                disabled={recommendMutation.isPending || (!userQuery && preferredGenres.length === 0)}
                className="w-full"
                data-testid="button-get-ai-recommendations"
              >
                {recommendMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    AI is thinking...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Get AI Recommendations
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          {recommendMutation.isPending && (
            <div className="space-y-4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-center gap-4">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                    <div>
                      <p className="font-medium">Analyzing your preferences...</p>
                      <p className="text-sm text-muted-foreground">
                        Gemini AI is finding personalized recommendations
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <div className="grid grid-cols-1 gap-4">
                {Array.from({ length: numRecs }).map((_, i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <Skeleton className="w-24 h-32 rounded-lg flex-shrink-0" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-6 w-3/4" />
                          <Skeleton className="h-4 w-1/4" />
                          <Skeleton className="h-4 w-full" />
                          <Skeleton className="h-4 w-full" />
                          <Skeleton className="h-4 w-2/3" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {recommendMutation.isError && (
            <Card>
              <CardContent className="p-8 text-center">
                <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
                <p className="text-lg font-medium">AI Recommendation Failed</p>
                <p className="text-sm text-muted-foreground mt-2">
                  {recommendMutation.error?.message || "Please try again with different preferences."}
                </p>
              </CardContent>
            </Card>
          )}

          {recommendMutation.isSuccess && recommendMutation.data && (
            <div className="space-y-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-4 flex-wrap">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-primary" />
                      <span className="font-medium">AI-Powered Recommendations</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Cpu className="w-4 h-4" />
                        <span>{recommendMutation.data.model}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{recommendMutation.data.processingTime.toFixed(0)}ms</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 gap-4">
                {recommendMutation.data.recommendations.map((movie, i) => (
                  <Card key={movie.title} className="overflow-visible">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <div className="w-24 h-32 bg-muted rounded-lg flex-shrink-0 flex items-center justify-center">
                          <Film className="w-10 h-10 text-muted-foreground/50" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 flex-wrap">
                            <div>
                              <h3 className="font-semibold text-lg leading-tight" data-testid={`text-movie-title-${i}`}>
                                {movie.title}
                              </h3>
                              {movie.year && (
                                <p className="text-sm text-muted-foreground">{movie.year}</p>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              {movie.voteAverage !== undefined && movie.voteAverage > 0 && (
                                <Badge variant="secondary" className="gap-1">
                                  <Star className="w-3 h-3 fill-current" />
                                  {movie.voteAverage.toFixed(1)}
                                </Badge>
                              )}
                              {movie.confidence && (
                                <Badge variant="outline" className="text-xs">
                                  {Math.round(movie.confidence * 100)}% match
                                </Badge>
                              )}
                            </div>
                          </div>
                          {movie.genres && (
                            <div className="flex flex-wrap gap-1.5 mt-2">
                              {movie.genres.split(", ").slice(0, 4).map((genre) => (
                                <Badge key={genre} variant="outline" className="text-xs">
                                  {genre}
                                </Badge>
                              ))}
                            </div>
                          )}
                          {movie.overview && (
                            <p className="text-sm text-muted-foreground mt-3 line-clamp-3" data-testid={`text-movie-overview-${i}`}>
                              {movie.overview}
                            </p>
                          )}
                          {movie.reason && (
                            <p className="text-sm text-primary/80 mt-2 italic" data-testid={`text-movie-reason-${i}`}>
                              {movie.reason}
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {!recommendMutation.isPending && !recommendMutation.isSuccess && !recommendMutation.isError && (
            <Card>
              <CardContent className="p-12 text-center">
                <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                  <Sparkles className="h-10 w-10 text-primary" />
                </div>
                <p className="text-xl font-semibold">Ready for AI Recommendations</p>
                <p className="text-sm text-muted-foreground mt-3 max-w-md mx-auto">
                  Describe what you're in the mood for or select your favorite genres. 
                  Our AI will suggest personalized movie recommendations with detailed descriptions.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
