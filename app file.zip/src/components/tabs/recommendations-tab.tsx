import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { MovieCard } from "@/components/movie-card";
import { CodeViewer } from "@/components/code-viewer";
import {
  Search,
  Loader2,
  Cpu,
  Clock,
  AlertTriangle,
  X,
  Film,
  Sparkles,
  Layers,
  Star,
  BrainCircuit,
  Info,
  ChevronDown,
  ChevronUp,
  GitCompare,
  PieChart,
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ContentBasedResult, GenAIResult, Movie, ComparisonResult, DiversityResult } from "@shared/schema";

const GENRE_OPTIONS = [
  "Action", "Adventure", "Animation", "Comedy", "Crime",
  "Documentary", "Drama", "Family", "Fantasy", "History",
  "Horror", "Music", "Mystery", "Romance", "Science Fiction",
  "Thriller", "War", "Western"
];

const tfidfCode = `# Content-Based Recommendation (TF-IDF)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors

# Create TF-IDF matrix from movie metadata
tfidf = TfidfVectorizer(stop_words='english', max_features=5000)
tfidf_matrix = tfidf.fit_transform(movies['combined_features'])

# Find similar movies using cosine similarity
knn = NearestNeighbors(metric='cosine', algorithm='brute')
knn.fit(tfidf_matrix)

def get_tfidf_recommendations(movie_idx, n=6):
    distances, indices = knn.kneighbors(
        tfidf_matrix[movie_idx], n_neighbors=n+1
    )
    return [(idx, 1-dist) for idx, dist in zip(indices[0][1:], distances[0][1:])]`;

const hybridWithAICode = `# Hybrid with AI Framework
# Combines TF-IDF + Metadata + Gemini API for contextual analysis

def hybrid_with_ai_recommend(user_query, seed_movie=None, genres=[], n=6):
    # Step 1: Get base candidates using TF-IDF similarity
    if seed_movie:
        candidates = get_tfidf_candidates(seed_movie, top_k=50)
    else:
        candidates = get_genre_based_candidates(genres, top_k=50)
    
    # Step 2: Apply weighted hybrid scoring
    scored_candidates = []
    for movie in candidates:
        score = compute_hybrid_score(movie, seed_movie, tfidf_sim=movie.similarity)
        scored_candidates.append((movie, score))
    
    # Step 3: Use Gemini API for contextual analysis & re-ranking
    top_candidates = sorted(scored_candidates, key=lambda x: -x[1])[:20]
    
    prompt = f"""
    User request: {user_query}
    Seed movie: {seed_movie}
    Preferred genres: {genres}
    
    Analyze and re-rank these candidates based on user intent:
    {format_candidates(top_candidates)}
    
    Return top {n} with match confidence and personalized reasons.
    """
    
    response = gemini.generate(prompt)
    return parse_ai_recommendations(response)

def compute_hybrid_score(movie, seed, tfidf_sim):
    # TF-IDF similarity (40% weight)
    content_score = tfidf_sim * 0.4
    
    # Genre overlap (30% weight)  
    genre_overlap = len(set(seed.genres) & set(movie.genres)) if seed else 0
    genre_score = (genre_overlap / max(len(seed.genres), 1)) * 0.3 if seed else 0.3
    
    # Rating quality (20% weight)
    rating_score = (movie.vote_average / 10) * 0.2
    
    # Popularity signal (10% weight)
    pop_score = normalize_popularity(movie.vote_count) * 0.1
    
    return content_score + genre_score + rating_score + pop_score`;

export function RecommendationsTab() {
  const { toast } = useToast();
  const [activeMethod, setActiveMethod] = useState("content-based");

  const [selectedMovie, setSelectedMovie] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const [numRecs, setNumRecs] = useState(6);

  const [userQuery, setUserQuery] = useState("");
  const [preferredGenres, setPreferredGenres] = useState<string[]>([]);
  const [expandedReasons, setExpandedReasons] = useState<Set<string>>(new Set());

  const toggleReasonExpand = (movieTitle: string) => {
    setExpandedReasons(prev => {
      const newSet = new Set(prev);
      if (newSet.has(movieTitle)) {
        newSet.delete(movieTitle);
      } else {
        newSet.add(movieTitle);
      }
      return newSet;
    });
  };

  const { data: movies, isLoading: moviesLoading } = useQuery<Movie[]>({
    queryKey: ["/api/movies"],
  });

  const contentMutation = useMutation<ContentBasedResult, Error, { movieTitle: string; numRecommendations: number; method: string }>({
    mutationFn: async (params) => {
      const res = await apiRequest("POST", "/api/recommendations/content", params);
      return res.json();
    },
  });

  const hybridAIMutation = useMutation<GenAIResult, Error, { userQuery: string; likedMovies: string[]; dislikedMovies: string[]; preferredGenres: string[]; numRecommendations?: number }>({
    mutationFn: async (params) => {
      const res = await apiRequest("POST", "/api/recommendations/genai", params);
      return res.json();
    },
    onError: (error) => {
      toast({
        title: "Hybrid AI Failed",
        description: error.message || "Could not get hybrid AI recommendations.",
        variant: "destructive",
      });
    },
  });

  const compareMutation = useMutation<ComparisonResult, Error, { movieTitle: string; numRecommendations: number }>({
    mutationFn: async (params) => {
      const res = await apiRequest("GET", `/api/analytics/compare?movieTitle=${encodeURIComponent(params.movieTitle)}&num=${params.numRecommendations}`);
      return res.json();
    },
    onError: (error) => {
      toast({
        title: "Comparison Failed",
        description: error.message || "Could not compare recommendation methods.",
        variant: "destructive",
      });
    },
  });

  const handleCompare = () => {
    if (!selectedMovie) return;
    compareMutation.mutate({
      movieTitle: selectedMovie,
      numRecommendations: numRecs,
    });
  };

  const filteredMovies = useMemo(() => {
    if (!movies || !searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    return movies.filter((m) => m.title.toLowerCase().includes(query)).slice(0, 10);
  }, [movies, searchQuery]);

  const handleSelectMovie = (title: string) => {
    setSelectedMovie(title);
    setSearchQuery(title);
    setShowDropdown(false);
  };

  const handleClearSelection = () => {
    setSelectedMovie("");
    setSearchQuery("");
  };

  const handleContentBased = () => {
    if (!selectedMovie) return;
    contentMutation.mutate({
      movieTitle: selectedMovie,
      numRecommendations: numRecs,
      method: "tfidf",
    });
  };

  const handleHybridAI = () => {
    hybridAIMutation.mutate({
      userQuery,
      likedMovies: selectedMovie ? [selectedMovie] : [],
      dislikedMovies: [],
      preferredGenres,
      numRecommendations: numRecs,
    });
  };

  const handleToggleGenre = (genre: string) => {
    if (preferredGenres.includes(genre)) {
      setPreferredGenres(preferredGenres.filter((g) => g !== genre));
    } else {
      setPreferredGenres([...preferredGenres, genre]);
    }
  };

  const MovieSearchInput = () => (
    <div className="space-y-2">
      <Label htmlFor="movie-search">Select a Movie</Label>
      <div className="relative">
        <div className="relative flex items-center">
          <Search className="absolute left-3 w-4 h-4 text-muted-foreground pointer-events-none" />
          <Input
            id="movie-search"
            placeholder="Type to search movies..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setShowDropdown(true);
              if (e.target.value !== selectedMovie) {
                setSelectedMovie("");
              }
            }}
            onFocus={() => setShowDropdown(true)}
            className="pl-9 pr-9"
            disabled={moviesLoading}
            data-testid="input-movie-search"
          />
          {searchQuery && (
            <button
              onClick={handleClearSelection}
              className="absolute right-3 text-muted-foreground"
              data-testid="button-clear-search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        {showDropdown && filteredMovies.length > 0 && !selectedMovie && (
          <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-md shadow-lg max-h-60 overflow-auto">
            {filteredMovies.map((movie) => (
              <button
                key={movie.id}
                onClick={() => handleSelectMovie(movie.title)}
                className="w-full px-3 py-2 text-left text-sm hover-elevate flex items-center gap-2"
                data-testid={`option-movie-${movie.id}`}
              >
                <Film className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <span className="truncate">{movie.title}</span>
                {movie.release_date && (
                  <span className="text-xs text-muted-foreground ml-auto">({movie.release_date.slice(0, 4)})</span>
                )}
              </button>
            ))}
          </div>
        )}
      </div>
      {selectedMovie && (
        <p className="text-sm text-primary">Selected: {selectedMovie}</p>
      )}
    </div>
  );

  const NumRecsSlider = ({ max = 12 }: { max?: number }) => (
    <div className="space-y-2">
      <Label>Recommendations: {numRecs}</Label>
      <Slider
        value={[numRecs]}
        onValueChange={([v]) => setNumRecs(v)}
        min={3}
        max={max}
        step={1}
        data-testid="slider-num-recs"
      />
    </div>
  );

  const LoadingSkeleton = ({ count }: { count: number }) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <Card key={i}>
          <CardContent className="p-4">
            <div className="flex gap-4">
              <Skeleton className="w-20 h-28 rounded-lg" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-full" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  const ErrorCard = ({ message }: { message?: string }) => (
    <Card>
      <CardContent className="p-8 text-center">
        <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
        <p className="text-lg font-medium">Recommendation Failed</p>
        <p className="text-sm text-muted-foreground mt-2">
          {message || "Please try again."}
        </p>
      </CardContent>
    </Card>
  );

  const ResultsHeader = ({ method, time }: { method: string; time: number }) => (
    <div className="flex items-center gap-6 flex-wrap">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Cpu className="w-4 h-4" />
        <span>Method: {method}</span>
      </div>
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Clock className="w-4 h-4" />
        <span>Time: {time.toFixed(0)}ms</span>
      </div>
    </div>
  );

  return (
    <div className="space-y-6" data-testid="recommendations-content">
      <div>
        <h2 className="text-2xl font-semibold mb-2">Recommendations</h2>
        <p className="text-muted-foreground">
          Discover movies using content-based filtering or our hybrid AI-powered recommendation system.
        </p>
      </div>

      <Tabs value={activeMethod} onValueChange={setActiveMethod} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 h-auto p-1">
          <TabsTrigger value="content-based" className="flex items-center gap-2 py-3" data-testid="subtab-content-based">
            <Search className="w-4 h-4" />
            <span className="hidden sm:inline">Content-Based (TF-IDF)</span>
            <span className="sm:hidden">TF-IDF</span>
          </TabsTrigger>
          <TabsTrigger value="hybrid-ai" className="flex items-center gap-2 py-3" data-testid="subtab-hybrid-ai">
            <BrainCircuit className="w-4 h-4" />
            <span className="hidden sm:inline">Hybrid with AI</span>
            <span className="sm:hidden">Hybrid+AI</span>
          </TabsTrigger>
          <TabsTrigger value="compare" className="flex items-center gap-2 py-3" data-testid="subtab-compare">
            <GitCompare className="w-4 h-4" />
            <span className="hidden sm:inline">Compare Methods</span>
            <span className="sm:hidden">Compare</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="content-based" className="space-y-6">
          <Card className="bg-gradient-to-r from-blue-600/5 to-transparent border-blue-600/20">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-700 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-sm">Content-Based Filtering (TF-IDF)</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Uses TF-IDF vectorization to find movies with similar plot descriptions, keywords, cast, and crew. 
                    Pure text similarity without metadata weighting or AI enhancement.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Search className="w-5 h-5" />
                Find Similar Movies
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <MovieSearchInput />
                <NumRecsSlider />
              </div>
              <Button
                onClick={handleContentBased}
                disabled={!selectedMovie || contentMutation.isPending}
                className="w-full md:w-auto"
                data-testid="button-content-recommend"
              >
                {contentMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Finding Similar...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Get Recommendations
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {contentMutation.isPending && <LoadingSkeleton count={numRecs} />}
          {contentMutation.isError && <ErrorCard message={contentMutation.error?.message} />}

          {contentMutation.isSuccess && contentMutation.data && (
            <>
              <ResultsHeader method="TF-IDF" time={contentMutation.data.processingTime} />
              <div>
                <h3 className="text-lg font-semibold mb-4">
                  Movies similar to "{contentMutation.data.inputMovie}"
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {contentMutation.data.recommendations.map((movie, i) => (
                    <MovieCard key={movie.title} movie={movie} index={i} />
                  ))}
                </div>
              </div>
            </>
          )}

          <CodeViewer
            title="TF-IDF Algorithm"
            code={tfidfCode}
            language="python"
            defaultOpen={false}
          />
        </TabsContent>

        <TabsContent value="hybrid-ai" className="space-y-6">
          <Card className="bg-gradient-to-r from-emerald-600/5 via-blue-600/5 to-transparent border-emerald-600/20">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <BrainCircuit className="w-5 h-5 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-sm flex items-center gap-2">
                    Hybrid with AI Framework
                    <Badge variant="secondary" className="text-xs">Recommended</Badge>
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Combines TF-IDF similarity (40%), genre overlap (30%), rating quality (20%), and popularity (10%) 
                    with Gemini AI for contextual analysis, intent understanding, and personalized explanations.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1">
              <CardHeader className="py-4">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  Your Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>What are you in the mood for?</Label>
                  <Textarea
                    placeholder="e.g., A mind-bending thriller with unexpected twists, or a feel-good comedy for the weekend..."
                    value={userQuery}
                    onChange={(e) => setUserQuery(e.target.value)}
                    className="min-h-24"
                    data-testid="input-hybrid-query"
                  />
                </div>

                <MovieSearchInput />

                <div className="space-y-2">
                  <Label>Preferred Genres</Label>
                  <div className="flex flex-wrap gap-1.5">
                    {GENRE_OPTIONS.map((genre) => (
                      <Badge
                        key={genre}
                        variant={preferredGenres.includes(genre) ? "default" : "outline"}
                        className="cursor-pointer text-xs toggle-elevate"
                        onClick={() => handleToggleGenre(genre)}
                        data-testid={`badge-genre-${genre.toLowerCase().replace(' ', '-')}`}
                      >
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>

                <NumRecsSlider max={10} />

                <Button
                  onClick={handleHybridAI}
                  disabled={hybridAIMutation.isPending || (!userQuery && preferredGenres.length === 0 && !selectedMovie)}
                  className="w-full"
                  data-testid="button-hybrid-ai-recommend"
                >
                  {hybridAIMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      AI Processing...
                    </>
                  ) : (
                    <>
                      <BrainCircuit className="w-4 h-4 mr-2" />
                      Get Hybrid AI Recommendations
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <div className="lg:col-span-2">
              {hybridAIMutation.isPending && (
                <div className="space-y-4">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-center gap-4">
                        <Loader2 className="w-8 h-8 animate-spin text-emerald-600 dark:text-emerald-400" />
                        <div>
                          <p className="font-medium">Hybrid AI analyzing your preferences...</p>
                          <p className="text-sm text-muted-foreground">
                            Combining TF-IDF + metadata scoring with Gemini contextual analysis
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <div className="grid grid-cols-1 gap-4">
                    {Array.from({ length: numRecs }).map((_, i) => (
                      <Card key={i}>
                        <CardContent className="p-4">
                          <div className="flex gap-4">
                            <Skeleton className="w-24 h-32 rounded-lg flex-shrink-0" />
                            <div className="flex-1 space-y-2">
                              <Skeleton className="h-6 w-3/4" />
                              <Skeleton className="h-4 w-1/4" />
                              <Skeleton className="h-4 w-full" />
                              <Skeleton className="h-4 w-2/3" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {hybridAIMutation.isError && <ErrorCard message={hybridAIMutation.error?.message} />}

              {hybridAIMutation.isSuccess && hybridAIMutation.data && (
                <div className="space-y-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between gap-4 flex-wrap">
                        <div className="flex items-center gap-2">
                          <BrainCircuit className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                          <span className="font-medium">Hybrid AI Results</span>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Cpu className="w-4 h-4" />
                            <span>{hybridAIMutation.data.model}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            <span>{hybridAIMutation.data.processingTime.toFixed(0)}ms</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="grid grid-cols-1 gap-4">
                    {hybridAIMutation.data.recommendations.map((movie, i) => (
                      <Card key={movie.title} className="overflow-visible">
                        <CardContent className="p-4">
                          <div className="flex gap-4">
                            <div className="w-24 h-32 bg-muted rounded-lg flex-shrink-0 flex items-center justify-center">
                              <Film className="w-10 h-10 text-muted-foreground/50" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2 flex-wrap">
                                <div>
                                  <h3 className="font-semibold text-lg leading-tight" data-testid={`text-hybrid-movie-${i}`}>
                                    {movie.title}
                                  </h3>
                                  {movie.year && (
                                    <p className="text-sm text-muted-foreground">{movie.year}</p>
                                  )}
                                </div>
                                <div className="flex items-center gap-2">
                                  {movie.voteAverage !== undefined && movie.voteAverage > 0 && (
                                    <Badge variant="secondary" className="gap-1">
                                      <Star className="w-3 h-3 fill-current" />
                                      {movie.voteAverage.toFixed(1)}
                                    </Badge>
                                  )}
                                  {movie.confidence && (
                                    <Badge variant="outline" className="text-xs">
                                      {Math.round(movie.confidence * 100)}% match
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              {movie.genres && (
                                <div className="flex flex-wrap gap-1.5 mt-2">
                                  {movie.genres.split(", ").slice(0, 4).map((genre) => (
                                    <Badge key={genre} variant="outline" className="text-xs">
                                      {genre}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                              {movie.overview && (
                                <p className="text-sm text-muted-foreground mt-3">
                                  {movie.overview}
                                </p>
                              )}
                              {movie.reason && (
                                <div className="mt-3 p-3 rounded-md bg-emerald-600/5 border border-emerald-600/10">
                                  <div className="flex items-start gap-2">
                                    <Sparkles className="w-4 h-4 flex-shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
                                    <div className="flex-1 min-w-0">
                                      <p className="text-xs font-medium text-emerald-700 dark:text-emerald-300 mb-1">
                                        AI Recommendation Reason
                                      </p>
                                      <p className={`text-sm text-muted-foreground ${!expandedReasons.has(movie.title) ? "line-clamp-3" : ""}`}>
                                        {movie.reason}
                                      </p>
                                      {movie.reason.length > 150 && (
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          className="mt-1"
                                          onClick={() => toggleReasonExpand(movie.title)}
                                          data-testid={`button-expand-reason-${i}`}
                                        >
                                          {expandedReasons.has(movie.title) ? (
                                            <>
                                              <ChevronUp className="w-3 h-3 mr-1" />
                                              Show less
                                            </>
                                          ) : (
                                            <>
                                              <ChevronDown className="w-3 h-3 mr-1" />
                                              Read full reason
                                            </>
                                          )}
                                        </Button>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {!hybridAIMutation.isPending && !hybridAIMutation.isSuccess && !hybridAIMutation.isError && (
                <Card>
                  <CardContent className="p-12 text-center">
                    <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-emerald-600/20 to-blue-600/10 flex items-center justify-center">
                      <BrainCircuit className="h-10 w-10 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <p className="text-xl font-semibold">Hybrid AI Discovery</p>
                    <p className="text-sm text-muted-foreground mt-3 max-w-md mx-auto">
                      This method combines content-based filtering (TF-IDF), metadata scoring (genre, rating, popularity), 
                      and Gemini AI for contextual analysis. Describe your mood, select a seed movie, or choose genres 
                      to get intelligent recommendations with personalized explanations.
                    </p>
                    <div className="mt-6 flex items-center justify-center gap-4 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Layers className="w-3 h-3" />
                        <span>TF-IDF 40%</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Film className="w-3 h-3" />
                        <span>Genre 30%</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3" />
                        <span>Rating 20%</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        <span>Popularity 10%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          <CodeViewer
            title="Hybrid with AI Framework"
            code={hybridWithAICode}
            language="python"
            defaultOpen={false}
          />
        </TabsContent>

        <TabsContent value="compare" className="space-y-6">
          <Card className="bg-gradient-to-r from-purple-600/5 to-transparent border-purple-600/20">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <GitCompare className="w-5 h-5 text-purple-700 dark:text-purple-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-sm">Compare Recommendation Methods</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    See side-by-side results from Content-Based (TF-IDF) and Hybrid with AI methods for the same movie.
                    Includes diversity scores to compare genre variety across methods.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <GitCompare className="w-5 h-5" />
                Select Movie to Compare
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <Label htmlFor="compare-search">Search Movie</Label>
                <div className="relative mt-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="compare-search"
                    placeholder="Type movie name..."
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setShowDropdown(true);
                    }}
                    onFocus={() => setShowDropdown(true)}
                    className="pl-10"
                    data-testid="input-compare-movie-search"
                  />
                  {selectedMovie && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute right-1 top-1/2 -translate-y-1/2"
                      onClick={handleClearSelection}
                      data-testid="button-compare-clear-selection"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                {showDropdown && filteredMovies.length > 0 && (
                  <div className="absolute z-10 w-full mt-1 border rounded-md bg-background shadow-lg max-h-60 overflow-auto">
                    {filteredMovies.map((movie) => (
                      <button
                        key={movie.id}
                        className="w-full px-3 py-2 text-left hover-elevate flex items-center gap-2"
                        onClick={() => handleSelectMovie(movie.title)}
                        data-testid={`compare-movie-option-${movie.id}`}
                      >
                        <Film className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{movie.title}</span>
                        {movie.release_date && (
                          <span className="text-sm text-muted-foreground">
                            ({movie.release_date.substring(0, 4)})
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <Label>Number of Recommendations: {numRecs}</Label>
                <Slider
                  value={[numRecs]}
                  onValueChange={([value]) => setNumRecs(value)}
                  min={3}
                  max={10}
                  step={1}
                  className="mt-2"
                  data-testid="slider-compare-num-recs"
                />
              </div>

              <Button
                onClick={handleCompare}
                disabled={!selectedMovie || compareMutation.isPending}
                className="w-full"
                data-testid="button-compare-methods"
              >
                {compareMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Comparing Methods...
                  </>
                ) : (
                  <>
                    <GitCompare className="w-4 h-4 mr-2" />
                    Compare Both Methods
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {compareMutation.data && (
            <div className="space-y-6">
              <div className="text-center">
                <p className="text-muted-foreground">
                  Comparing recommendations for <span className="font-medium text-foreground">{compareMutation.data.inputMovie}</span>
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Processed in {compareMutation.data.processingTime}ms
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-blue-600/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Search className="w-5 h-5 text-blue-700 dark:text-blue-400" />
                      Content-Based (TF-IDF)
                    </CardTitle>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="secondary" className="gap-1">
                        <PieChart className="w-3 h-3" />
                        Diversity: {Math.round(compareMutation.data.diversityContentBased.diversityIndex * 100)}%
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {compareMutation.data.diversityContentBased.uniqueGenres} genres
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {compareMutation.data.diversityContentBased.interpretation}
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {compareMutation.data.contentBased.map((movie, i) => (
                      <div key={movie.title} className="p-3 rounded-lg border" data-testid={`compare-content-movie-${i}`}>
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h4 className="font-medium text-sm">{movie.title}</h4>
                          <Badge variant="outline" className="text-xs shrink-0 gap-1">
                            <Star className="w-3 h-3 text-yellow-500" />
                            {movie.vote_average.toFixed(1)}
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-1 mb-2">
                          {movie.genres?.split(/\s+/).slice(0, 3).map((genre) => (
                            <Badge key={genre} variant="secondary" className="text-xs">
                              {genre}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Similarity: {(movie.similarity * 100).toFixed(1)}%
                        </p>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="border-emerald-600/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <BrainCircuit className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                      Hybrid with AI
                    </CardTitle>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="secondary" className="gap-1">
                        <PieChart className="w-3 h-3" />
                        Diversity: {Math.round(compareMutation.data.diversityHybridWithAI.diversityIndex * 100)}%
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {compareMutation.data.diversityHybridWithAI.uniqueGenres} genres
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {compareMutation.data.diversityHybridWithAI.interpretation}
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {compareMutation.data.hybridWithAI.map((movie, i) => (
                      <div key={movie.title} className="p-3 rounded-lg border" data-testid={`compare-hybrid-movie-${i}`}>
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h4 className="font-medium text-sm">{movie.title}</h4>
                          <Badge variant="outline" className="text-xs shrink-0 gap-1">
                            <Star className="w-3 h-3 text-yellow-500" />
                            {movie.vote_average.toFixed(1)}
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-1 mb-2">
                          {movie.genres?.split(/\s+/).slice(0, 3).map((genre) => (
                            <Badge key={genre} variant="secondary" className="text-xs">
                              {genre}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Similarity: {(movie.similarity * 100).toFixed(1)}%
                        </p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <PieChart className="w-5 h-5" />
                    Genre Distribution Comparison
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm font-medium mb-2 text-blue-700 dark:text-blue-400">Content-Based</p>
                      <div className="flex flex-wrap gap-2">
                        {compareMutation.data.diversityContentBased.genreDistribution.map((g) => (
                          <Badge key={g.genre} variant="outline" className="gap-1">
                            {g.genre}
                            <span className="text-muted-foreground">({g.percentage}%)</span>
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-2 text-emerald-600 dark:text-emerald-400">Hybrid with AI</p>
                      <div className="flex flex-wrap gap-2">
                        {compareMutation.data.diversityHybridWithAI.genreDistribution.map((g) => (
                          <Badge key={g.genre} variant="outline" className="gap-1">
                            {g.genre}
                            <span className="text-muted-foreground">({g.percentage}%)</span>
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
