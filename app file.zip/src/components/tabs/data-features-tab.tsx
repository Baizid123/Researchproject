import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/stat-card";
import { DataTable } from "@/components/data-table";
import { CodeViewer } from "@/components/code-viewer";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Database, 
  Film, 
  Star, 
  CheckCircle, 
  AlertTriangle,
  Layers,
  Hash,
  FileText,
  Cpu,
  Workflow,
  Grid3X3,
} from "lucide-react";
import type { PreprocessingStats, FeatureEngineering, Movie } from "@shared/schema";

const preprocessingCode = `# Data Preprocessing Pipeline
import pandas as pd
import numpy as np

# Load the dataset
df = pd.read_csv('movies.csv')
print(f"Loaded {len(df)} movies")

# Display basic info
print("\\nDataset Shape:", df.shape)
print("\\nColumn Types:")
print(df.dtypes)

# Handle missing values
def clean_data(df):
    # Fill missing overviews with empty string
    df['overview'] = df['overview'].fillna('')
    
    # Fill missing genres
    df['genres'] = df['genres'].fillna('')
    
    # Fill numeric columns with median
    numeric_cols = ['budget', 'revenue', 'runtime', 'vote_average']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = df[col].fillna(df[col].median())
    
    return df

df = clean_data(df)

# Create combined text feature for TF-IDF
df['combined'] = (
    df['title'].astype(str) + ' ' + 
    df['genres'].str.replace('|', ' ') + ' ' + 
    df['overview'].astype(str) + ' ' +
    df['keywords'].astype(str).str.replace('|', ' ')
)

print("\\nPreprocessing complete!")`;

const featureEngineeringCode = `# Feature Engineering - TF-IDF Vectorization
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize
import numpy as np

# Initialize TF-IDF Vectorizer
vectorizer = TfidfVectorizer(
    max_features=20000,       # Limit vocabulary size
    stop_words='english',     # Remove common words
    ngram_range=(1, 2),       # Use unigrams and bigrams
    min_df=2,                 # Minimum document frequency
    max_df=0.95,              # Maximum document frequency
    sublinear_tf=True         # Apply sublinear tf scaling
)

# Fit and transform the combined text
print("Fitting TF-IDF vectorizer...")
tfidf_matrix = vectorizer.fit_transform(df['combined'])

print(f"TF-IDF Matrix Shape: {tfidf_matrix.shape}")
print(f"Vocabulary Size: {len(vectorizer.vocabulary_)}")

# Normalize the TF-IDF matrix for cosine similarity
tfidf_normalized = normalize(tfidf_matrix, norm='l2')

print("\\nFeature engineering complete!")`;

export function DataFeaturesTab() {
  const { data: stats, isLoading: statsLoading, error: statsError } = useQuery<PreprocessingStats>({
    queryKey: ["/api/preprocessing"],
  });

  const { data: features, isLoading: featuresLoading, error: featuresError } = useQuery<FeatureEngineering>({
    queryKey: ["/api/features"],
  });

  const isLoading = statsLoading || featuresLoading;
  const error = statsError || featuresError;

  if (isLoading) {
    return (
      <div className="space-y-6" data-testid="data-features-loading">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-4 w-20 mb-2" />
                <Skeleton className="h-8 w-14" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Skeleton className="h-96 w-full rounded-md" />
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <p className="text-lg font-medium">Failed to load data</p>
          <p className="text-sm text-muted-foreground mt-2">
            Please check the server connection and try again.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (!stats || !features) return null;

  const tableColumns = ["index", "title", "genres", "vote_average", "popularity", "runtime"];
  const tableData = stats.sampleData.map((movie) => ({
    index: movie.index,
    title: movie.title,
    genres: movie.genres?.replace(/\s+/g, ", ") || "-",
    vote_average: movie.vote_average,
    popularity: movie.popularity?.toFixed(2),
    runtime: movie.runtime ? `${movie.runtime} min` : "-",
  }));

  const missingValueData = Object.entries(stats.missingValues || {})
    .map(([column, count]) => ({
      column,
      missing: count,
      percentage: ((count / stats.totalMovies) * 100).toFixed(2) + "%",
    }))
    .filter((d) => d.missing > 0);

  return (
    <div className="space-y-6" data-testid="data-features-content">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-semibold mb-1">Data & Feature Engineering</h2>
          <p className="text-muted-foreground">
            Dataset exploration, preprocessing, and TF-IDF vectorization
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 border-cyan-500/20">
            <Database className="h-3 w-3 mr-1" />
            {stats.totalMovies.toLocaleString()} Movies
          </Badge>
          <Badge className="bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20">
            <Layers className="h-3 w-3 mr-1" />
            {features.tfidfShape[1].toLocaleString()} Features
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard
          title="Movies"
          value={stats.totalMovies.toLocaleString()}
          icon={Film}
          description="Total records"
          compact
        />
        <StatCard
          title="Genres"
          value={stats.uniqueGenres}
          icon={Database}
          description="Categories"
          compact
        />
        <StatCard
          title="Avg Rating"
          value={stats.avgRating.toFixed(2)}
          icon={Star}
          description="Mean score"
          compact
        />
        <StatCard
          title="Quality"
          value={`${stats.dataQuality.toFixed(0)}%`}
          icon={CheckCircle}
          description="Non-null"
          compact
        />
        <StatCard
          title="TF-IDF Cols"
          value={features.tfidfShape[1].toLocaleString()}
          icon={Hash}
          description="Dimensions"
          compact
        />
        <StatCard
          title="Vocabulary"
          value={features.vocabularySize.toLocaleString()}
          icon={FileText}
          description="Unique terms"
          compact
        />
      </div>

      <Tabs defaultValue="dataset" className="space-y-4">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="dataset" className="gap-2" data-testid="subtab-dataset">
            <Grid3X3 className="h-4 w-4" />
            Dataset Preview
          </TabsTrigger>
          <TabsTrigger value="features" className="gap-2" data-testid="subtab-features">
            <Layers className="h-4 w-4" />
            TF-IDF Features
          </TabsTrigger>
          <TabsTrigger value="pipeline" className="gap-2" data-testid="subtab-pipeline">
            <Workflow className="h-4 w-4" />
            Pipeline Code
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dataset" className="space-y-6 mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <DataTable
                title="Movie Dataset"
                data={tableData}
                columns={tableColumns}
                pageSize={10}
              />
            </div>
            <div className="space-y-4">
              <Card>
                <CardHeader className="py-4">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    Missing Values
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {missingValueData.length > 0 ? (
                    missingValueData.slice(0, 6).map((item) => (
                      <div key={item.column} className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="truncate">{item.column}</span>
                          <span className="text-muted-foreground">{item.percentage}</span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-amber-500 rounded-full"
                            style={{ width: item.percentage }}
                          />
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-4 text-muted-foreground">
                      <CheckCircle className="h-8 w-8 mx-auto mb-2 text-emerald-500" />
                      <p className="text-sm">No significant missing values</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="py-4">
                  <CardTitle className="text-lg">Column Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(stats.columnTypes || {}).slice(0, 8).map(([col, type]) => (
                      <div key={col} className="flex justify-between text-sm">
                        <span className="truncate text-muted-foreground">{col}</span>
                        <code className="text-xs bg-muted px-2 py-0.5 rounded">{type}</code>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="features" className="space-y-6 mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Top Features by TF-IDF Weight
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {features.topFeatures.slice(0, 12).map((feature, i) => {
                    const colors = [
                      "bg-cyan-500",
                      "bg-purple-500",
                      "bg-amber-500",
                      "bg-rose-500",
                      "bg-emerald-500",
                      "bg-blue-500",
                    ];
                    return (
                      <div key={feature.term} className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium">
                            <span className="text-muted-foreground mr-2">{i + 1}.</span>
                            {feature.term}
                          </span>
                          <span className="text-muted-foreground font-mono text-xs">
                            {feature.weight.toFixed(4)}
                          </span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${colors[i % colors.length]}`}
                            style={{
                              width: `${(feature.weight / features.topFeatures[0].weight) * 100}%`,
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">TF-IDF Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-4 bg-gradient-to-br from-cyan-500/10 to-cyan-500/5 rounded-lg border border-cyan-500/20">
                      <p className="text-sm text-muted-foreground">Max Features</p>
                      <p className="text-xl font-bold text-cyan-600 dark:text-cyan-400">20,000</p>
                    </div>
                    <div className="p-4 bg-gradient-to-br from-purple-500/10 to-purple-500/5 rounded-lg border border-purple-500/20">
                      <p className="text-sm text-muted-foreground">N-gram Range</p>
                      <p className="text-xl font-bold text-purple-600 dark:text-purple-400">(1, 2)</p>
                    </div>
                    <div className="p-4 bg-gradient-to-br from-amber-500/10 to-amber-500/5 rounded-lg border border-amber-500/20">
                      <p className="text-sm text-muted-foreground">Min Doc Freq</p>
                      <p className="text-xl font-bold text-amber-600 dark:text-amber-400">2</p>
                    </div>
                    <div className="p-4 bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 rounded-lg border border-emerald-500/20">
                      <p className="text-sm text-muted-foreground">Max Doc Freq</p>
                      <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">95%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Text Sources</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { name: "Title", color: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300" },
                      { name: "Genres", color: "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300" },
                      { name: "Overview", color: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300" },
                      { name: "Keywords", color: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300" },
                      { name: "Cast", color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300" },
                      { name: "Director", color: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300" },
                    ].map((source) => (
                      <span
                        key={source.name}
                        className={`px-3 py-1.5 rounded-full text-sm font-medium ${source.color}`}
                      >
                        {source.name}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Processing Steps</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {[
                      { step: "Lowercase conversion", color: "bg-cyan-500" },
                      { step: "Stop words removal", color: "bg-purple-500" },
                      { step: "Sublinear TF scaling", color: "bg-amber-500" },
                      { step: "L2 normalization", color: "bg-emerald-500" },
                    ].map((item) => (
                      <li key={item.step} className="flex items-center gap-3 text-sm">
                        <span className={`w-2 h-2 rounded-full ${item.color}`} />
                        {item.step}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="pipeline" className="space-y-6 mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <CodeViewer
              title="Data Preprocessing Code"
              code={preprocessingCode}
              language="python"
              defaultOpen={true}
            />
            <CodeViewer
              title="Feature Engineering Code"
              code={features.codeOutput || featureEngineeringCode}
              language="python"
              defaultOpen={true}
            />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function TrendingUp(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
      <polyline points="16 7 22 7 22 13" />
    </svg>
  );
}
