import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Sector,
} from "recharts";
import {
  Database,
  Film,
  Star,
  TrendingUp,
  Brain,
  Sparkles,
  Target,
  BarChart3,
  Layers,
  ArrowRight,
  Zap,
  CheckCircle,
  RefreshCw,
  Search,
  Clock,
  Calendar,
  Users,
  Loader2,
  X,
  History,
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import type {
  PreprocessingStats,
  FeatureEngineering,
  VisualizationData,
  Movie,
  ContentBasedResult,
  TrendingMovie,
} from "@shared/schema";
import { MovieComparison } from "@/components/movie-comparison";
import { WatchlistPanel } from "@/components/watchlist-panel";
import { MovieDetailsModal } from "@/components/movie-details-modal";

const CHART_COLORS = [
  "hsl(195, 85%, 50%)",
  "hsl(270, 75%, 58%)",
  "hsl(330, 70%, 56%)",
  "hsl(45, 90%, 55%)",
  "hsl(150, 60%, 48%)",
  "hsl(0, 80%, 55%)",
];

const GENRE_COLORS: Record<string, { bg: string; text: string; gradient: string }> = {
  Action: { bg: "bg-red-100 dark:bg-red-900/40", text: "text-red-600 dark:text-red-400", gradient: "from-red-500 to-orange-500" },
  Comedy: { bg: "bg-yellow-100 dark:bg-yellow-900/40", text: "text-yellow-600 dark:text-yellow-400", gradient: "from-yellow-500 to-amber-500" },
  Drama: { bg: "bg-purple-100 dark:bg-purple-900/40", text: "text-purple-600 dark:text-purple-400", gradient: "from-purple-500 to-violet-500" },
  Horror: { bg: "bg-gray-100 dark:bg-gray-900/40", text: "text-gray-600 dark:text-gray-400", gradient: "from-gray-700 to-gray-900" },
  Romance: { bg: "bg-pink-100 dark:bg-pink-900/40", text: "text-pink-600 dark:text-pink-400", gradient: "from-pink-500 to-rose-500" },
  Thriller: { bg: "bg-slate-100 dark:bg-slate-900/40", text: "text-slate-600 dark:text-slate-400", gradient: "from-slate-600 to-slate-800" },
  Adventure: { bg: "bg-emerald-100 dark:bg-emerald-900/40", text: "text-emerald-600 dark:text-emerald-400", gradient: "from-emerald-500 to-teal-500" },
  Fantasy: { bg: "bg-indigo-100 dark:bg-indigo-900/40", text: "text-indigo-600 dark:text-indigo-400", gradient: "from-indigo-500 to-purple-500" },
  Animation: { bg: "bg-cyan-100 dark:bg-cyan-900/40", text: "text-cyan-600 dark:text-cyan-400", gradient: "from-cyan-500 to-blue-500" },
  Crime: { bg: "bg-orange-100 dark:bg-orange-900/40", text: "text-orange-600 dark:text-orange-400", gradient: "from-orange-600 to-red-600" },
  Family: { bg: "bg-green-100 dark:bg-green-900/40", text: "text-green-600 dark:text-green-400", gradient: "from-green-500 to-emerald-500" },
  "Science Fiction": { bg: "bg-blue-100 dark:bg-blue-900/40", text: "text-blue-600 dark:text-blue-400", gradient: "from-blue-500 to-cyan-500" },
};

interface RecentRecommendation {
  movieTitle: string;
  timestamp: number;
  resultCount: number;
}

interface QuickStatProps {
  title: string;
  value: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
}

function QuickStat({ title, value, icon: Icon, color, bgColor }: QuickStatProps) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-4">
          <div className={`flex items-center justify-center h-12 w-12 rounded-md ${bgColor}`}>
            <Icon className={`h-6 w-6 ${color}`} />
          </div>
          <div>
            <p className="text-2xl font-bold">{value}</p>
            <p className="text-sm text-muted-foreground">{title}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface FeatureCardProps {
  title: string;
  description: string;
  icon: React.ElementType;
  gradient: string;
  onClick?: () => void;
}

function FeatureCard({ title, description, icon: Icon, gradient, onClick }: FeatureCardProps) {
  return (
    <Card 
      className="group cursor-pointer overflow-visible hover-elevate active-elevate-2"
      onClick={onClick}
      data-testid={`feature-card-${title.toLowerCase().replace(/\s+/g, "-")}`}
    >
      <CardContent className="p-6">
        <div className={`flex items-center justify-center h-12 w-12 rounded-md mb-4 ${gradient}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
        <h3 className="font-semibold text-lg mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground mb-4">{description}</p>
        <div className="flex items-center gap-1 text-sm font-medium text-primary">
          Explore
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </div>
      </CardContent>
    </Card>
  );
}

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent } = props;
  return (
    <g>
      <text x={cx} y={cy - 10} textAnchor="middle" className="fill-foreground text-sm font-medium">
        {payload.genre}
      </text>
      <text x={cx} y={cy + 10} textAnchor="middle" className="fill-muted-foreground text-xs">
        {`${(percent * 100).toFixed(0)}%`}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius + 8}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 10}
        outerRadius={outerRadius + 14}
        fill={fill}
      />
    </g>
  );
};

interface DashboardTabProps {
  onTabChange: (tabId: string) => void;
}

export function DashboardTab({ onTabChange }: DashboardTabProps) {
  const [activeGenreIndex, setActiveGenreIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [recentRecs, setRecentRecs] = useState<RecentRecommendation[]>([]);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const { data: stats, isLoading: statsLoading } = useQuery<PreprocessingStats>({
    queryKey: ["/api/preprocessing"],
  });

  const { data: features, isLoading: featuresLoading } = useQuery<FeatureEngineering>({
    queryKey: ["/api/features"],
  });

  const { data: vizData, isLoading: vizLoading } = useQuery<VisualizationData>({
    queryKey: ["/api/visualizations"],
  });

  const { data: movies, isLoading: moviesLoading } = useQuery<Movie[]>({
    queryKey: ["/api/movies"],
  });

  const { data: trendingMovies, isLoading: trendingLoading } = useQuery<TrendingMovie[]>({
    queryKey: ["/api/analytics/trending?limit=6"],
  });

  const [spotlightMovie, setSpotlightMovie] = useState<Movie | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("recentRecommendations");
    if (stored) {
      try {
        setRecentRecs(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to parse recent recommendations");
      }
    }
  }, []);

  useEffect(() => {
    if (movies && movies.length > 0 && !spotlightMovie) {
      const validMovies = movies.filter(m => m.vote_average >= 7 && m.overview);
      const randomIdx = Math.floor(Math.random() * Math.min(validMovies.length, 200));
      setSpotlightMovie(validMovies[randomIdx] || movies[0]);
    }
  }, [movies, spotlightMovie]);

  const refreshSpotlight = () => {
    if (movies && movies.length > 0) {
      const validMovies = movies.filter(m => m.vote_average >= 7 && m.overview);
      const randomIdx = Math.floor(Math.random() * Math.min(validMovies.length, 200));
      setSpotlightMovie(validMovies[randomIdx] || movies[0]);
    }
  };

  const quickRecMutation = useMutation<ContentBasedResult, Error, { movieTitle: string }>({
    mutationFn: async (params) => {
      const res = await apiRequest("POST", "/api/recommendations/content", {
        movieTitle: params.movieTitle,
        numRecommendations: 6,
      });
      return res.json();
    },
    onSuccess: (data) => {
      const newRec: RecentRecommendation = {
        movieTitle: data.inputMovie,
        timestamp: Date.now(),
        resultCount: data.recommendations.length,
      };
      setRecentRecs((prev) => {
        const updated = [newRec, ...prev.filter(r => r.movieTitle !== data.inputMovie)].slice(0, 5);
        localStorage.setItem("recentRecommendations", JSON.stringify(updated));
        return updated;
      });
      onTabChange("recommendations");
    },
  });

  const searchResults = useMemo(() => {
    if (!searchQuery.trim() || !movies) return [];
    const query = searchQuery.toLowerCase();
    return movies
      .filter(m => m.title.toLowerCase().includes(query))
      .slice(0, 8);
  }, [searchQuery, movies]);

  const filteredGenreMovies = useMemo(() => {
    if (!selectedGenre || !movies) return [];
    return movies
      .filter(m => m.genres?.toLowerCase().includes(selectedGenre.toLowerCase()) && m.vote_average >= 6)
      .sort((a, b) => b.vote_average - a.vote_average)
      .slice(0, 6);
  }, [selectedGenre, movies]);

  const isLoading = statsLoading || featuresLoading;

  const topGenres = ["Action", "Comedy", "Drama", "Romance", "Thriller", "Adventure", "Fantasy", "Animation", "Crime", "Horror"];

  if (isLoading) {
    return (
      <div className="space-y-8" data-testid="dashboard-loading">
        <div className="text-center space-y-4 py-8">
          <Skeleton className="h-10 w-96 mx-auto" />
          <Skeleton className="h-6 w-80 mx-auto" />
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-24 rounded-md" />
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-48 rounded-md" />
          ))}
        </div>
      </div>
    );
  }

  const quickStats = [
    {
      title: "Total Movies",
      value: stats?.totalMovies?.toLocaleString() || "0",
      icon: Film,
      color: "text-cyan-600 dark:text-cyan-400",
      bgColor: "bg-cyan-100 dark:bg-cyan-900/40",
    },
    {
      title: "Unique Genres",
      value: stats?.uniqueGenres?.toString() || "0",
      icon: Database,
      color: "text-purple-600 dark:text-purple-400",
      bgColor: "bg-purple-100 dark:bg-purple-900/40",
    },
    {
      title: "TF-IDF Features",
      value: features?.tfidfShape?.[1]?.toLocaleString() || "0",
      icon: Layers,
      color: "text-amber-600 dark:text-amber-400",
      bgColor: "bg-amber-100 dark:bg-amber-900/40",
    },
    {
      title: "Avg Rating",
      value: stats?.avgRating?.toFixed(1) || "0",
      icon: Star,
      color: "text-rose-600 dark:text-rose-400",
      bgColor: "bg-rose-100 dark:bg-rose-900/40",
    },
  ];

  const featureCards = [
    {
      title: "Data & Features",
      description: "Explore the movie dataset, preprocessing steps, and TF-IDF vectorization",
      icon: Database,
      gradient: "bg-gradient-to-br from-cyan-500 to-blue-600",
      tabId: "data-features",
    },
    {
      title: "Visualizations",
      description: "Interactive charts showing genre distribution, ratings, and trends",
      icon: BarChart3,
      gradient: "bg-gradient-to-br from-purple-500 to-pink-600",
      tabId: "visualization",
    },
    {
      title: "Recommendations",
      description: "Content-based, hybrid, and AI-assisted movie recommendations",
      icon: Sparkles,
      gradient: "bg-gradient-to-br from-amber-500 to-orange-600",
      tabId: "recommendations",
    },
    {
      title: "Model Evaluation",
      description: "Qualitative analysis of recommendation relevance, coherence, and consistency",
      icon: Target,
      gradient: "bg-gradient-to-br from-emerald-500 to-teal-600",
      tabId: "evaluation",
    },
  ];

  const pieData = vizData?.genreDistribution?.slice(0, 6) || [];

  const clearRecentRecs = () => {
    setRecentRecs([]);
    localStorage.removeItem("recentRecommendations");
  };

  return (
    <div className="space-y-10" data-testid="dashboard-content">
      <div className="text-center space-y-4 py-4">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary">
          <Zap className="h-4 w-4" />
          <span className="text-sm font-medium">AI-Powered Movie Recommendations</span>
        </div>
        <h1 className="text-4xl font-bold tracking-tight">
          Movie Recommendation
          <span className="bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 bg-clip-text text-transparent"> Dashboard</span>
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Discover movies using content-based filtering with TF-IDF vectorization and Google Gemini AI
        </p>
      </div>

      <Card data-testid="quick-search-card">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search for a movie to get recommendations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-10"
              data-testid="input-quick-search"
            />
            {searchQuery && (
              <Button
                size="icon"
                variant="ghost"
                className="absolute right-1 top-1/2 -translate-y-1/2"
                onClick={() => setSearchQuery("")}
                data-testid="button-clear-search"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          {searchResults.length > 0 && (
            <div className="mt-3 border rounded-md divide-y" data-testid="search-results">
              {searchResults.map((movie) => (
                <button
                  key={movie.id}
                  className="w-full flex items-center justify-between p-3 text-left hover-elevate active-elevate-2"
                  onClick={() => {
                    quickRecMutation.mutate({ movieTitle: movie.title });
                    setSearchQuery("");
                  }}
                  disabled={quickRecMutation.isPending}
                  data-testid={`search-result-${movie.id}`}
                >
                  <div className="flex items-center gap-3">
                    <Film className="h-4 w-4 text-muted-foreground shrink-0" />
                    <div>
                      <p className="font-medium line-clamp-1">{movie.title}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{movie.genres?.split(" ").slice(0, 2).join(", ")}</span>
                        <span className="flex items-center gap-1">
                          <Star className="h-3 w-3 text-amber-500" />
                          {movie.vote_average?.toFixed(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                  {quickRecMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  )}
                </button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {quickStats.map((stat) => (
          <QuickStat key={stat.title} {...stat} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1" data-testid="genre-chart-card">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg">Genre Distribution</CardTitle>
            <BarChart3 className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {vizLoading ? (
              <Skeleton className="h-48 w-full" />
            ) : (
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      activeIndex={activeGenreIndex}
                      activeShape={renderActiveShape}
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={65}
                      dataKey="count"
                      nameKey="genre"
                      onMouseEnter={(_, index) => setActiveGenreIndex(index)}
                    >
                      {pieData.map((_, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={CHART_COLORS[index % CHART_COLORS.length]}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="w-full mt-2"
              onClick={() => onTabChange("visualization")}
              data-testid="button-view-all-charts"
            >
              View All Charts
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2" data-testid="movie-spotlight-card">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-amber-500" />
              Movie Spotlight
            </CardTitle>
            <Button
              size="icon"
              variant="ghost"
              onClick={refreshSpotlight}
              disabled={moviesLoading}
              data-testid="button-refresh-spotlight"
            >
              <RefreshCw className={`h-4 w-4 ${moviesLoading ? "animate-spin" : ""}`} />
            </Button>
          </CardHeader>
          <CardContent>
            {moviesLoading || !spotlightMovie ? (
              <div className="flex gap-4">
                <Skeleton className="w-28 h-40 rounded-lg shrink-0" />
                <div className="flex-1 space-y-3">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-20 w-full" />
                </div>
              </div>
            ) : (
              <div className="flex gap-4">
                <div className="w-28 h-40 rounded-lg bg-gradient-to-br from-purple-500/20 to-cyan-500/20 flex items-center justify-center shrink-0">
                  <Film className="h-10 w-10 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-lg line-clamp-1">{spotlightMovie.title}</h3>
                  <div className="flex items-center gap-3 mt-1 flex-wrap">
                    <Badge variant="secondary" className="gap-1">
                      <Star className="h-3 w-3 text-amber-500" />
                      {spotlightMovie.vote_average?.toFixed(1)}
                    </Badge>
                    <span className="text-sm text-muted-foreground flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {spotlightMovie.release_date?.split("-")[0]}
                    </span>
                    {spotlightMovie.runtime > 0 && (
                      <span className="text-sm text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {spotlightMovie.runtime} min
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                    {spotlightMovie.overview}
                  </p>
                  <div className="flex items-center gap-2 mt-3 flex-wrap">
                    {spotlightMovie.genres?.split(" ").slice(0, 3).map((genre) => (
                      <Badge key={genre} variant="outline" className="text-xs">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                  <Button
                    size="sm"
                    className="mt-3"
                    onClick={() => quickRecMutation.mutate({ movieTitle: spotlightMovie.title })}
                    disabled={quickRecMutation.isPending}
                    data-testid="button-spotlight-recommend"
                  >
                    {quickRecMutation.isPending ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <TrendingUp className="h-4 w-4 mr-2" />
                    )}
                    Find Similar Movies
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card data-testid="mood-selector-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">What are you in the mood for?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {topGenres.map((genre) => {
              const colors = GENRE_COLORS[genre] || { bg: "bg-muted", text: "text-foreground", gradient: "from-gray-500 to-gray-600" };
              const isSelected = selectedGenre === genre;
              return (
                <Button
                  key={genre}
                  variant="outline"
                  size="sm"
                  className={`transition-all ${isSelected ? `bg-gradient-to-r ${colors.gradient} text-white border-transparent` : ""}`}
                  onClick={() => setSelectedGenre(isSelected ? null : genre)}
                  data-testid={`button-genre-${genre.toLowerCase()}`}
                >
                  {genre}
                </Button>
              );
            })}
          </div>
          {selectedGenre && (
            <div className="mt-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium">Top {selectedGenre} Movies</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedGenre(null)}
                  data-testid="button-clear-genre"
                >
                  Clear
                </Button>
              </div>
              {moviesLoading ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <Skeleton key={i} className="h-24 rounded-md" />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3" data-testid="genre-movies-grid">
                  {filteredGenreMovies.map((movie) => (
                    <button
                      key={movie.id}
                      className="p-3 rounded-md border text-left hover-elevate active-elevate-2"
                      onClick={() => quickRecMutation.mutate({ movieTitle: movie.title })}
                      disabled={quickRecMutation.isPending}
                      data-testid={`genre-movie-${movie.id}`}
                    >
                      <p className="font-medium text-sm line-clamp-1">{movie.title}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <Star className="h-3 w-3 text-amber-500" />
                        <span className="text-xs text-muted-foreground">{movie.vote_average?.toFixed(1)}</span>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {recentRecs.length > 0 && (
        <Card data-testid="recent-recs-card">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <History className="h-5 w-5 text-muted-foreground" />
              Recent Recommendations
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearRecentRecs}
              data-testid="button-clear-recent"
            >
              Clear
            </Button>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {recentRecs.map((rec) => (
                <button
                  key={rec.timestamp}
                  className="flex items-center gap-2 px-3 py-2 rounded-md border hover-elevate active-elevate-2"
                  onClick={() => quickRecMutation.mutate({ movieTitle: rec.movieTitle })}
                  disabled={quickRecMutation.isPending}
                  data-testid={`recent-rec-${rec.timestamp}`}
                >
                  <Film className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium text-sm">{rec.movieTitle}</span>
                  <Badge variant="secondary" className="text-xs">
                    {rec.resultCount} results
                  </Badge>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card data-testid="trending-movies-card">
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            Trending Movies
          </CardTitle>
          <Badge variant="secondary" className="gap-1">
            Based on popularity & votes
          </Badge>
        </CardHeader>
        <CardContent>
          {trendingLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-32" />
              ))}
            </div>
          ) : trendingMovies && trendingMovies.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {trendingMovies.map((movie, i) => (
                <div
                  key={movie.title}
                  className="p-4 rounded-lg border hover-elevate cursor-pointer"
                  onClick={() => quickRecMutation.mutate({ movieTitle: movie.title })}
                  data-testid={`trending-movie-${i}`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h4 className="font-medium text-sm line-clamp-1">{movie.title}</h4>
                    <Badge variant="outline" className="text-xs shrink-0 gap-1">
                      <Star className="h-3 w-3 text-yellow-500" />
                      {movie.vote_average.toFixed(1)}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-2">
                    {movie.genres?.split(/\s+/).slice(0, 2).map((genre) => (
                      <Badge key={genre} variant="secondary" className="text-xs">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" />
                      {Math.round(movie.trendScore * 100)}%
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {movie.vote_count.toLocaleString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {movie.release_date?.substring(0, 4)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">No trending movies available</p>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" data-testid="comparison-watchlist-section">
        <div className="lg:col-span-2">
          <MovieComparison />
        </div>
        <WatchlistPanel onMovieClick={(movie) => {
          setSelectedMovie(movie);
          setDetailsOpen(true);
        }} />
      </div>

      <MovieDetailsModal 
        movie={selectedMovie}
        open={detailsOpen}
        onOpenChange={(open) => {
          setDetailsOpen(open);
          if (!open) setSelectedMovie(null);
        }}
      />

      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold">Explore Features</h2>
          <Badge variant="secondary" className="gap-1">
            <CheckCircle className="h-3 w-3" />
            All Systems Ready
          </Badge>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featureCards.map((card) => (
            <FeatureCard
              key={card.title}
              {...card}
              onClick={() => onTabChange(card.tabId)}
            />
          ))}
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
          <CardTitle className="text-lg">Unified Recommendation System</CardTitle>
          <Sparkles className="h-5 w-5 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Three recommendation approaches in one module: Content-Based (TF-IDF), Hybrid (TF-IDF + Metadata), 
            and AI-Assisted (Hybrid + Gemini for explanations).
          </p>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="p-3 rounded-lg bg-muted/50 text-center">
              <p className="text-xs text-muted-foreground">Content-Based</p>
              <p className="font-medium text-sm">TF-IDF</p>
            </div>
            <div className="p-3 rounded-lg bg-muted/50 text-center">
              <p className="text-xs text-muted-foreground">Hybrid</p>
              <p className="font-medium text-sm">Multi-Signal</p>
            </div>
            <div className="p-3 rounded-lg bg-muted/50 text-center">
              <p className="text-xs text-muted-foreground">AI-Assisted</p>
              <p className="font-medium text-sm">Gemini 2.5</p>
            </div>
          </div>
          <Button 
            className="w-full" 
            onClick={() => onTabChange("recommendations")}
            data-testid="button-explore-recommendations"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Explore Recommendations
          </Button>
        </CardContent>
      </Card>

    </div>
  );
}
