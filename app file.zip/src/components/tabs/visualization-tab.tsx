import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip as TooltipUI, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { AlertTriangle, Film, Star, Users, TrendingUp, Calendar, Grid3X3 } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
  ComposedChart,
  Area,
} from "recharts";
import type { VisualizationData, CorrelationCell } from "@shared/schema";

function getCorrelationColor(value: number): string {
  if (value >= 0.7) return "bg-blue-600 dark:bg-blue-500";
  if (value >= 0.4) return "bg-blue-400 dark:bg-blue-400";
  if (value >= 0.2) return "bg-blue-200 dark:bg-blue-700";
  if (value >= -0.2) return "bg-gray-100 dark:bg-gray-700";
  if (value >= -0.4) return "bg-red-200 dark:bg-red-700";
  if (value >= -0.7) return "bg-red-400 dark:bg-red-400";
  return "bg-red-600 dark:bg-red-500";
}

function getCorrelationTextColor(value: number): string {
  if (Math.abs(value) >= 0.4) return "text-white";
  return "text-foreground";
}

interface HeatmapCellProps {
  cell: CorrelationCell;
}

function HeatmapCell({ cell }: HeatmapCellProps) {
  const bgColor = getCorrelationColor(cell.value);
  const textColor = getCorrelationTextColor(cell.value);
  
  return (
    <TooltipUI>
      <TooltipTrigger asChild>
        <div
          className={`aspect-square flex items-center justify-center text-xs font-medium rounded-sm cursor-pointer transition-transform hover:scale-105 ${bgColor} ${textColor}`}
          data-testid={`heatmap-cell-${cell.x}-${cell.y}`}
        >
          {cell.value.toFixed(2)}
        </div>
      </TooltipTrigger>
      <TooltipContent>
        <p className="font-medium">{cell.x} vs {cell.y}</p>
        <p className="text-sm">Correlation: {cell.value.toFixed(3)}</p>
      </TooltipContent>
    </TooltipUI>
  );
}

interface CorrelationHeatmapProps {
  features: string[];
  matrix: CorrelationCell[];
}

function CorrelationHeatmap({ features, matrix }: CorrelationHeatmapProps) {
  const matrixMap = new Map<string, number>();
  matrix.forEach(cell => {
    matrixMap.set(`${cell.x}-${cell.y}`, cell.value);
  });

  const getCell = (x: string, y: string): CorrelationCell => {
    const value = matrixMap.get(`${x}-${y}`) ?? matrixMap.get(`${y}-${x}`) ?? (x === y ? 1 : 0);
    return { x, y, value };
  };

  const gridSize = features.length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-center gap-4 text-xs">
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 rounded-sm bg-red-600 dark:bg-red-500" />
          <span>-1.0</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 rounded-sm bg-red-200 dark:bg-red-700" />
          <span>-0.5</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 rounded-sm bg-gray-100 dark:bg-gray-700" />
          <span>0</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 rounded-sm bg-blue-200 dark:bg-blue-700" />
          <span>0.5</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 rounded-sm bg-blue-600 dark:bg-blue-500" />
          <span>1.0</span>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <div className="min-w-fit">
          <div
            className="grid gap-1"
            style={{
              gridTemplateColumns: `100px repeat(${gridSize}, minmax(50px, 1fr))`,
            }}
          >
            <div />
            {features.map((feature) => (
              <div
                key={`header-${feature}`}
                className="text-xs font-medium text-center truncate px-1"
                title={feature}
              >
                {feature.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}
              </div>
            ))}

            {features.map((rowFeature) => (
              <>
                <div
                  key={`row-${rowFeature}`}
                  className="text-xs font-medium text-right pr-2 flex items-center justify-end"
                  title={rowFeature}
                >
                  {rowFeature.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}
                </div>
                {features.map((colFeature) => (
                  <HeatmapCell
                    key={`${rowFeature}-${colFeature}`}
                    cell={getCell(rowFeature, colFeature)}
                  />
                ))}
              </>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const COLORS = [
  "hsl(195, 85%, 50%)",
  "hsl(270, 75%, 58%)",
  "hsl(210, 65%, 52%)",
  "hsl(330, 70%, 56%)",
  "hsl(150, 60%, 48%)",
  "hsl(45, 90%, 55%)",
  "hsl(0, 80%, 55%)",
  "hsl(180, 70%, 45%)",
];

export function VisualizationTab() {
  const { data: vizData, isLoading, error } = useQuery<VisualizationData>({
    queryKey: ["/api/visualizations"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" data-testid="viz-loading">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-40" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-64 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <p className="text-lg font-medium">Failed to load visualization data</p>
          <p className="text-sm text-muted-foreground mt-2">
            Please check the server connection and try again.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (!vizData) return null;

  const topGenres = vizData.genreDistribution.slice(0, 10);
  const pieData = vizData.genreDistribution.slice(0, 8);

  return (
    <div className="space-y-6" data-testid="viz-content">
      <div>
        <h2 className="text-2xl font-semibold mb-2">Visualization</h2>
        <p className="text-muted-foreground">
          Interactive charts exploring movie dataset patterns and distributions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card data-testid="chart-genre-distribution">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Film className="h-5 w-5 text-cyan-500" />
              Genre Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={topGenres}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 80, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis type="number" tick={{ fontSize: 12 }} />
                  <YAxis
                    dataKey="genre"
                    type="category"
                    tick={{ fontSize: 12 }}
                    width={70}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    labelStyle={{ color: "hsl(var(--foreground))" }}
                  />
                  <Bar
                    dataKey="count"
                    fill="hsl(195, 85%, 50%)"
                    radius={[0, 4, 4, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="chart-genre-pie">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg">Genre Share (Top 8)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    fill="#8884d8"
                    paddingAngle={2}
                    dataKey="count"
                    nameKey="genre"
                    label={({ genre, percent }) =>
                      `${genre} (${(percent * 100).toFixed(0)}%)`
                    }
                    labelLine={{ stroke: "hsl(var(--muted-foreground))" }}
                  >
                    {pieData.map((_, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="chart-movies-per-year">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Calendar className="h-5 w-5 text-purple-500" />
              Movies Released Per Year
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={vizData.moviesPerYear}
                  margin={{ top: 5, right: 30, left: 20, bottom: 25 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis
                    dataKey="year"
                    tick={{ fontSize: 10 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                    interval={1}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number) => [value, "Movies"]}
                  />
                  <Bar
                    dataKey="count"
                    fill="hsl(270, 75%, 58%)"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="chart-avg-rating-year">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-emerald-500" />
              Average Rating Per Year
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={vizData.avgRatingPerYear}
                  margin={{ top: 5, right: 30, left: 20, bottom: 25 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis
                    dataKey="year"
                    tick={{ fontSize: 10 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                    interval={1}
                  />
                  <YAxis tick={{ fontSize: 12 }} domain={[5, 8]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number) => [value.toFixed(2), "Avg Rating"]}
                  />
                  <Line
                    type="monotone"
                    dataKey="avgRating"
                    stroke="hsl(150, 60%, 48%)"
                    strokeWidth={2}
                    dot={{ fill: "hsl(150, 60%, 48%)", strokeWidth: 0, r: 3 }}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="chart-rating-distribution">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Star className="h-5 w-5 text-amber-500" />
              Rating Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={vizData.ratingDistribution}
                  margin={{ top: 5, right: 30, left: 20, bottom: 25 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis
                    dataKey="range"
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number) => [value, "Movies"]}
                  />
                  <Bar
                    dataKey="count"
                    fill="hsl(45, 90%, 55%)"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="chart-avg-rating-genre">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Star className="h-5 w-5 text-rose-500" />
              Average Rating by Genre
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={vizData.avgRatingByGenre}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 100, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis type="number" tick={{ fontSize: 12 }} domain={[0, 10]} />
                  <YAxis
                    dataKey="genre"
                    type="category"
                    tick={{ fontSize: 12 }}
                    width={90}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number, name: string) => {
                      if (name === "avgRating") return [value.toFixed(2), "Avg Rating"];
                      return [value, name];
                    }}
                  />
                  <Bar
                    dataKey="avgRating"
                    fill="hsl(330, 70%, 56%)"
                    radius={[0, 4, 4, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card data-testid="chart-top-directors-count">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-500" />
              Top Directors by Movie Count
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={vizData.topDirectorsByCount}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 120, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis type="number" tick={{ fontSize: 12 }} />
                  <YAxis
                    dataKey="director"
                    type="category"
                    tick={{ fontSize: 11 }}
                    width={110}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number, name: string) => {
                      if (name === "movieCount") return [value, "Movies"];
                      return [value, name];
                    }}
                  />
                  <Bar
                    dataKey="movieCount"
                    fill="hsl(210, 65%, 52%)"
                    radius={[0, 4, 4, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="chart-top-directors-rating">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Star className="h-5 w-5 text-amber-500" />
              Top Directors by Avg Rating
              <span className="text-xs text-muted-foreground font-normal">(min 3 movies)</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart
                  data={vizData.topDirectorsByRating}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 120, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis type="number" tick={{ fontSize: 12 }} domain={[0, 10]} />
                  <YAxis
                    dataKey="director"
                    type="category"
                    tick={{ fontSize: 11 }}
                    width={110}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number, name: string) => {
                      if (name === "avgRating") return [value.toFixed(2), "Avg Rating"];
                      if (name === "movieCount") return [value, "Movies"];
                      return [value, name];
                    }}
                  />
                  <Legend />
                  <Bar
                    dataKey="avgRating"
                    name="avgRating"
                    fill="hsl(0, 80%, 55%)"
                    radius={[0, 4, 4, 0]}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card data-testid="chart-popularity-trend">
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-teal-500" />
            Popularity Trend by Year (2000-2020)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                data={vizData.popularityTrend}
                margin={{ top: 10, right: 30, left: 20, bottom: 25 }}
              >
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis
                  dataKey="year"
                  tick={{ fontSize: 11 }}
                  angle={-45}
                  textAnchor="end"
                  height={60}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                  formatter={(value: number) => [value.toFixed(2), "Avg Popularity"]}
                />
                <Area
                  type="monotone"
                  dataKey="avgPopularity"
                  fill="hsl(180, 70%, 45%)"
                  fillOpacity={0.2}
                  stroke="hsl(180, 70%, 45%)"
                  strokeWidth={2}
                />
                <Line
                  type="monotone"
                  dataKey="avgPopularity"
                  stroke="hsl(180, 70%, 45%)"
                  strokeWidth={2}
                  dot={{ fill: "hsl(180, 70%, 45%)", strokeWidth: 0 }}
                  activeDot={{ r: 6, strokeWidth: 0 }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {vizData.correlationData && (
        <Card data-testid="chart-correlation-heatmap">
          <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Grid3X3 className="h-5 w-5 text-indigo-500" />
              Feature Correlation Heatmap
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Pearson correlation coefficients between numeric movie features. Blue indicates positive correlation, red indicates negative correlation.
            </p>
            <CorrelationHeatmap
              features={vizData.correlationData.features}
              matrix={vizData.correlationData.matrix}
            />
          </CardContent>
        </Card>
      )}
    </div>
  );
}
