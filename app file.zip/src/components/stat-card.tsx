import { Card, CardContent } from "@/components/ui/card";
import type { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  description?: string;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  compact?: boolean;
}

export function StatCard({ title, value, icon: Icon, description, trend, trendValue, compact }: StatCardProps) {
  if (compact) {
    return (
      <Card data-testid={`stat-card-${title.toLowerCase().replace(/\s+/g, "-")}`}>
        <CardContent className="p-3">
          <div className="flex items-center gap-2">
            <div className="flex-shrink-0 p-2 rounded-md bg-primary/10">
              <Icon className="h-4 w-4 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-lg font-bold truncate">{value}</p>
              <p className="text-xs text-muted-foreground truncate">{title}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid={`stat-card-${title.toLowerCase().replace(/\s+/g, "-")}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <p className="text-sm text-muted-foreground truncate">{title}</p>
            <p className="text-2xl font-bold mt-1 truncate">{value}</p>
            {description && (
              <p className="text-xs text-muted-foreground mt-1">{description}</p>
            )}
            {trend && trendValue && (
              <div className={`flex items-center gap-1 mt-2 text-xs ${
                trend === "up" ? "text-green-500" : 
                trend === "down" ? "text-red-500" : "text-muted-foreground"
              }`}>
                {trend === "up" && <span>+</span>}
                {trend === "down" && <span>-</span>}
                <span>{trendValue}</span>
              </div>
            )}
          </div>
          <div className="flex-shrink-0 p-3 rounded-xl bg-primary/10">
            <Icon className="h-6 w-6 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
