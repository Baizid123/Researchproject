import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useWatchlist } from "@/hooks/use-watchlist";
import {
  Bookmark,
  Film,
  Star,
  Calendar,
  Clock,
  X,
  Trash2,
} from "lucide-react";
import type { Movie } from "@shared/schema";

interface WatchlistItemProps {
  movie: Movie;
  onRemove: () => void;
  onClick?: () => void;
}

function WatchlistItem({ movie, onRemove, onClick }: WatchlistItemProps) {
  return (
    <div
      className="flex items-start gap-3 p-3 rounded-md hover-elevate cursor-pointer group"
      onClick={onClick}
      data-testid={`watchlist-item-${movie.id}`}
    >
      <div className="w-12 h-16 rounded bg-gradient-to-br from-purple-500/20 to-cyan-500/20 flex items-center justify-center shrink-0">
        <Film className="h-5 w-5 text-muted-foreground" />
      </div>
      <div className="flex-1 min-w-0">
        <h4 className="font-medium text-sm line-clamp-1">{movie.title}</h4>
        <div className="flex items-center gap-2 mt-1 flex-wrap">
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <Star className="h-3 w-3 text-amber-500" />
            {movie.vote_average?.toFixed(1)}
          </span>
          {movie.release_date && (
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {movie.release_date.split("-")[0]}
            </span>
          )}
          {movie.runtime > 0 && (
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {movie.runtime}m
            </span>
          )}
        </div>
        {movie.genres && (
          <div className="flex gap-1 mt-1.5 flex-wrap">
            {movie.genres.split(" ").slice(0, 2).map((genre) => (
              <Badge key={genre} variant="outline" className="text-xs py-0">
                {genre}
              </Badge>
            ))}
          </div>
        )}
      </div>
      <Button
        size="icon"
        variant="ghost"
        className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={(e) => {
          e.stopPropagation();
          onRemove();
        }}
        data-testid={`button-remove-watchlist-${movie.id}`}
      >
        <X className="h-4 w-4" />
      </Button>
    </div>
  );
}

interface WatchlistPanelProps {
  onMovieClick?: (movie: Movie) => void;
}

export function WatchlistPanel({ onMovieClick }: WatchlistPanelProps) {
  const { watchlist, removeFromWatchlist, clearWatchlist } = useWatchlist();

  return (
    <Card data-testid="watchlist-panel">
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <Bookmark className="h-5 w-5 text-amber-500" />
          My Watchlist
          {watchlist.length > 0 && (
            <Badge variant="secondary" className="ml-1">
              {watchlist.length}
            </Badge>
          )}
        </CardTitle>
        {watchlist.length > 0 && (
          <Button
            size="sm"
            variant="ghost"
            onClick={clearWatchlist}
            data-testid="button-clear-watchlist"
          >
            <Trash2 className="h-4 w-4 mr-1" />
            Clear
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {watchlist.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
            <Bookmark className="h-10 w-10 mb-3 opacity-50" />
            <p className="text-sm font-medium">No movies in your watchlist</p>
            <p className="text-xs mt-1">Add movies to keep track of what to watch</p>
          </div>
        ) : (
          <ScrollArea className="h-[300px]">
            <div className="space-y-1">
              {watchlist.map((movie) => (
                <WatchlistItem
                  key={movie.id}
                  movie={movie}
                  onRemove={() => removeFromWatchlist(movie.id)}
                  onClick={() => onMovieClick?.(movie)}
                />
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
