import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, ThumbsUp, ThumbsDown, Film } from "lucide-react";
import type { MovieRecommendation, GenAIRecommendation } from "@shared/schema";

interface MovieCardProps {
  movie: MovieRecommendation | GenAIRecommendation;
  index: number;
  onLike?: () => void;
  onDislike?: () => void;
  showActions?: boolean;
}

function isMovieRecommendation(movie: MovieRecommendation | GenAIRecommendation): movie is MovieRecommendation {
  return "similarity" in movie || "overview" in movie;
}

export function MovieCard({ movie, index, onLike, onDislike, showActions = false }: MovieCardProps) {
  const isContentBased = isMovieRecommendation(movie);
  
  return (
    <Card 
      className="group overflow-visible hover-elevate"
      data-testid={`movie-card-${index}`}
    >
      <CardContent className="p-4">
        <div className="flex gap-4">
          <div className="flex-shrink-0 w-20 h-28 rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
            <Film className="w-8 h-8 text-primary/60" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-semibold text-base truncate" data-testid={`text-movie-title-${index}`}>
              {movie.title}
            </h4>
            
            {isContentBased && movie.genres && (
              <div className="flex flex-wrap gap-1 mt-2">
                {movie.genres.split(" ").slice(0, 3).map((genre, i) => (
                  <Badge key={i} variant="secondary" className="text-xs">
                    {genre}
                  </Badge>
                ))}
              </div>
            )}
            
            {isContentBased && movie.vote_average !== undefined && (
              <div className="flex items-center gap-1 mt-2 text-sm">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                <span className="font-medium">{movie.vote_average.toFixed(1)}</span>
              </div>
            )}
            
            {isContentBased && movie.similarity !== undefined && (
              <div className="mt-2">
                <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                  <span>Similarity</span>
                  <span>{(movie.similarity * 100).toFixed(1)}%</span>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-primary rounded-full transition-all duration-500"
                    style={{ width: `${movie.similarity * 100}%` }}
                  />
                </div>
              </div>
            )}
            
            {movie.reason && (
              <p className="text-sm text-muted-foreground mt-2 line-clamp-2 italic">
                {movie.reason}
              </p>
            )}
            
            {isContentBased && movie.overview && !movie.reason && (
              <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                {movie.overview}
              </p>
            )}
          </div>
        </div>
        
        {showActions && (
          <div className="flex items-center gap-2 mt-4 pt-3 border-t border-border">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onLike}
              className="flex-1"
              data-testid={`button-like-movie-${index}`}
            >
              <ThumbsUp className="w-4 h-4 mr-2" />
              Like
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onDislike}
              className="flex-1"
              data-testid={`button-dislike-movie-${index}`}
            >
              <ThumbsDown className="w-4 h-4 mr-2" />
              Dislike
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
