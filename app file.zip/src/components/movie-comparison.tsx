import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import {
  Film,
  Star,
  Clock,
  DollarSign,
  TrendingUp,
  Users,
  Calendar,
  ArrowLeftRight,
  X,
  Search,
} from "lucide-react";
import type { Movie } from "@shared/schema";

interface MetricRowProps {
  label: string;
  icon: React.ElementType;
  movie1Value: number | string;
  movie2Value: number | string;
  formatFn?: (value: number | string) => string;
  higherIsBetter?: boolean;
}

function MetricRow({ label, icon: Icon, movie1Value, movie2Value, formatFn, higherIsBetter = true }: MetricRowProps) {
  const format = formatFn || ((v: number | string) => String(v));
  const val1 = typeof movie1Value === 'number' ? movie1Value : parseFloat(movie1Value) || 0;
  const val2 = typeof movie2Value === 'number' ? movie2Value : parseFloat(movie2Value) || 0;
  
  const maxVal = Math.max(val1, val2, 1);
  const percentage1 = (val1 / maxVal) * 100;
  const percentage2 = (val2 / maxVal) * 100;
  
  const winner1 = higherIsBetter ? val1 > val2 : val1 < val2;
  const winner2 = higherIsBetter ? val2 > val1 : val2 < val1;

  return (
    <div className="grid grid-cols-[1fr_auto_1fr] gap-4 items-center py-3 border-b last:border-0">
      <div className="text-right">
        <div className={`text-lg font-semibold ${winner1 ? 'text-emerald-600 dark:text-emerald-400' : ''}`}>
          {format(movie1Value)}
        </div>
        <Progress value={percentage1} className="h-2 mt-1" />
      </div>
      
      <div className="flex flex-col items-center gap-1 px-2">
        <Icon className="h-4 w-4 text-muted-foreground" />
        <span className="text-xs text-muted-foreground font-medium text-center">{label}</span>
      </div>
      
      <div className="text-left">
        <div className={`text-lg font-semibold ${winner2 ? 'text-emerald-600 dark:text-emerald-400' : ''}`}>
          {format(movie2Value)}
        </div>
        <Progress value={percentage2} className="h-2 mt-1" />
      </div>
    </div>
  );
}

export function MovieComparison() {
  const [movie1Id, setMovie1Id] = useState<string>("");
  const [movie2Id, setMovie2Id] = useState<string>("");
  const [search1, setSearch1] = useState("");
  const [search2, setSearch2] = useState("");

  const { data: movies, isLoading } = useQuery<Movie[]>({
    queryKey: ["/api/movies"],
  });

  const filteredMovies1 = useMemo(() => {
    if (!movies || !search1.trim()) return movies?.slice(0, 20) || [];
    const query = search1.toLowerCase();
    return movies.filter(m => m.title.toLowerCase().includes(query)).slice(0, 20);
  }, [movies, search1]);

  const filteredMovies2 = useMemo(() => {
    if (!movies || !search2.trim()) return movies?.slice(0, 20) || [];
    const query = search2.toLowerCase();
    return movies.filter(m => m.title.toLowerCase().includes(query)).slice(0, 20);
  }, [movies, search2]);

  const movie1 = useMemo(() => {
    if (!movies || !movie1Id) return null;
    return movies.find(m => String(m.id) === movie1Id);
  }, [movies, movie1Id]);

  const movie2 = useMemo(() => {
    if (!movies || !movie2Id) return null;
    return movies.find(m => String(m.id) === movie2Id);
  }, [movies, movie2Id]);

  const swapMovies = () => {
    const temp = movie1Id;
    setMovie1Id(movie2Id);
    setMovie2Id(temp);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Skeleton className="h-40" />
            <Skeleton className="h-40" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatCurrency = (value: number | string) => {
    const num = typeof value === 'number' ? value : parseFloat(value) || 0;
    if (num >= 1000000000) return `$${(num / 1000000000).toFixed(1)}B`;
    if (num >= 1000000) return `$${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `$${(num / 1000).toFixed(0)}K`;
    return `$${num}`;
  };

  const formatNumber = (value: number | string) => {
    const num = typeof value === 'number' ? value : parseFloat(value) || 0;
    return num.toLocaleString();
  };

  const formatRating = (value: number | string) => {
    const num = typeof value === 'number' ? value : parseFloat(value) || 0;
    return num.toFixed(1);
  };

  const formatMinutes = (value: number | string) => {
    const num = typeof value === 'number' ? value : parseFloat(value) || 0;
    return `${num} min`;
  };

  return (
    <Card data-testid="movie-comparison">
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <ArrowLeftRight className="h-5 w-5 text-blue-500" />
          Movie Comparison
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-4 items-end">
          <div className="space-y-2">
            <label className="text-sm font-medium">Movie 1</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search movies..."
                value={search1}
                onChange={(e) => setSearch1(e.target.value)}
                className="pl-10 mb-2"
                data-testid="input-search-movie1"
              />
            </div>
            <Select value={movie1Id} onValueChange={setMovie1Id}>
              <SelectTrigger data-testid="select-movie1">
                <SelectValue placeholder="Select a movie" />
              </SelectTrigger>
              <SelectContent>
                {filteredMovies1.map((movie) => (
                  <SelectItem key={movie.id} value={String(movie.id)}>
                    <span className="flex items-center gap-2">
                      <Film className="h-3 w-3" />
                      <span className="truncate">{movie.title}</span>
                      <Badge variant="secondary" className="ml-auto">
                        {movie.vote_average?.toFixed(1)}
                      </Badge>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button
            size="icon"
            variant="outline"
            onClick={swapMovies}
            className="mt-6"
            disabled={!movie1Id && !movie2Id}
            data-testid="button-swap-movies"
          >
            <ArrowLeftRight className="h-4 w-4" />
          </Button>

          <div className="space-y-2">
            <label className="text-sm font-medium">Movie 2</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search movies..."
                value={search2}
                onChange={(e) => setSearch2(e.target.value)}
                className="pl-10 mb-2"
                data-testid="input-search-movie2"
              />
            </div>
            <Select value={movie2Id} onValueChange={setMovie2Id}>
              <SelectTrigger data-testid="select-movie2">
                <SelectValue placeholder="Select a movie" />
              </SelectTrigger>
              <SelectContent>
                {filteredMovies2.map((movie) => (
                  <SelectItem key={movie.id} value={String(movie.id)}>
                    <span className="flex items-center gap-2">
                      <Film className="h-3 w-3" />
                      <span className="truncate">{movie.title}</span>
                      <Badge variant="secondary" className="ml-auto">
                        {movie.vote_average?.toFixed(1)}
                      </Badge>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {movie1 && movie2 ? (
          <div className="space-y-4">
            <div className="grid grid-cols-[1fr_auto_1fr] gap-4 items-center py-4 bg-muted/30 rounded-md px-4">
              <div className="text-center">
                <h3 className="font-semibold text-lg line-clamp-2">{movie1.title}</h3>
                <p className="text-sm text-muted-foreground">{movie1.release_date?.split("-")[0]}</p>
                <div className="flex flex-wrap gap-1 mt-2 justify-center">
                  {movie1.genres?.split(" ").slice(0, 2).map((genre) => (
                    <Badge key={genre} variant="outline" className="text-xs">
                      {genre}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="text-2xl font-bold text-muted-foreground">VS</div>
              
              <div className="text-center">
                <h3 className="font-semibold text-lg line-clamp-2">{movie2.title}</h3>
                <p className="text-sm text-muted-foreground">{movie2.release_date?.split("-")[0]}</p>
                <div className="flex flex-wrap gap-1 mt-2 justify-center">
                  {movie2.genres?.split(" ").slice(0, 2).map((genre) => (
                    <Badge key={genre} variant="outline" className="text-xs">
                      {genre}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <div className="border rounded-md p-4">
              <MetricRow
                label="Rating"
                icon={Star}
                movie1Value={movie1.vote_average || 0}
                movie2Value={movie2.vote_average || 0}
                formatFn={formatRating}
                higherIsBetter={true}
              />
              <MetricRow
                label="Votes"
                icon={Users}
                movie1Value={movie1.vote_count || 0}
                movie2Value={movie2.vote_count || 0}
                formatFn={formatNumber}
                higherIsBetter={true}
              />
              <MetricRow
                label="Runtime"
                icon={Clock}
                movie1Value={movie1.runtime || 0}
                movie2Value={movie2.runtime || 0}
                formatFn={formatMinutes}
                higherIsBetter={false}
              />
              <MetricRow
                label="Budget"
                icon={DollarSign}
                movie1Value={movie1.budget || 0}
                movie2Value={movie2.budget || 0}
                formatFn={formatCurrency}
                higherIsBetter={false}
              />
              <MetricRow
                label="Revenue"
                icon={DollarSign}
                movie1Value={movie1.revenue || 0}
                movie2Value={movie2.revenue || 0}
                formatFn={formatCurrency}
                higherIsBetter={true}
              />
              <MetricRow
                label="Popularity"
                icon={TrendingUp}
                movie1Value={movie1.popularity || 0}
                movie2Value={movie2.popularity || 0}
                formatFn={(v) => typeof v === 'number' ? v.toFixed(1) : parseFloat(v).toFixed(1)}
                higherIsBetter={true}
              />
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <Film className="h-12 w-12 mb-4 opacity-50" />
            <p className="text-lg font-medium">Select two movies to compare</p>
            <p className="text-sm">Choose movies from the dropdowns above</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
