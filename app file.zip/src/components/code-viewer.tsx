import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronUp, Copy, Check } from "lucide-react";

interface CodeViewerProps {
  title: string;
  code: string;
  language?: string;
  defaultOpen?: boolean;
}

export function CodeViewer({ title, code, language = "python", defaultOpen = false }: CodeViewerProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const lines = code.split("\n");

  return (
    <Card data-testid={`code-viewer-${title.toLowerCase().replace(/\s+/g, "-")}`}>
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CardHeader className="py-3 px-4">
          <div className="flex items-center justify-between gap-2">
            <CollapsibleTrigger asChild>
              <Button 
                variant="ghost" 
                className="flex items-center gap-2 p-0 h-auto hover:bg-transparent"
                data-testid={`button-toggle-code-${title.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <CardTitle className="text-sm font-medium">{title}</CardTitle>
                {isOpen ? (
                  <ChevronUp className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                )}
              </Button>
            </CollapsibleTrigger>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground font-mono bg-muted px-2 py-1 rounded">
                {language}
              </span>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleCopy}
                className="h-8 w-8"
                data-testid={`button-copy-code-${title.toLowerCase().replace(/\s+/g, "-")}`}
              >
                {copied ? (
                  <Check className="h-4 w-4 text-green-500" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CollapsibleContent>
          <CardContent className="p-0">
            <div className="max-h-96 overflow-auto bg-muted/30 rounded-b-lg">
              <pre className="p-4 text-sm font-mono">
                <code className="block">
                  {lines.map((line, i) => (
                    <div key={i} className="flex">
                      <span className="w-10 text-muted-foreground text-right pr-4 select-none">
                        {i + 1}
                      </span>
                      <span className="flex-1 whitespace-pre-wrap break-all">{line}</span>
                    </div>
                  ))}
                </code>
              </pre>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
