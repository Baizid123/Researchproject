import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useWatchlist } from "@/hooks/use-watchlist";
import {
  Film,
  Star,
  Calendar,
  Clock,
  DollarSign,
  TrendingUp,
  Users,
  Bookmark,
  BookmarkCheck,
  Globe,
  Building2,
  MapPin,
  Languages,
} from "lucide-react";
import type { Movie } from "@shared/schema";

interface MovieDetailsModalProps {
  movie: Movie | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface DetailRowProps {
  icon: React.ElementType;
  label: string;
  value: string | number;
}

function DetailRow({ icon: Icon, label, value }: DetailRowProps) {
  if (!value || value === "0" || value === "$0") return null;
  
  return (
    <div className="flex items-start gap-3 py-2">
      <Icon className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium">{value}</p>
      </div>
    </div>
  );
}

export function MovieDetailsModal({ movie, open, onOpenChange }: MovieDetailsModalProps) {
  const { addToWatchlist, removeFromWatchlist, isInWatchlist } = useWatchlist();

  if (!movie) return null;

  const inWatchlist = isInWatchlist(movie.id);

  const formatCurrency = (value: number) => {
    if (!value || value === 0) return null;
    if (value >= 1000000000) return `$${(value / 1000000000).toFixed(1)}B`;
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value}`;
  };

  const handleWatchlistToggle = () => {
    if (inWatchlist) {
      removeFromWatchlist(movie.id);
    } else {
      addToWatchlist(movie);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh]" data-testid="movie-details-modal">
        <DialogHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-xl line-clamp-2" data-testid="text-movie-title">
                {movie.title}
              </DialogTitle>
              {movie.original_title && movie.original_title !== movie.title && (
                <p className="text-sm text-muted-foreground mt-1">
                  Original: {movie.original_title}
                </p>
              )}
            </div>
            <Button
              variant={inWatchlist ? "default" : "outline"}
              size="sm"
              onClick={handleWatchlistToggle}
              data-testid="button-toggle-watchlist"
            >
              {inWatchlist ? (
                <>
                  <BookmarkCheck className="h-4 w-4 mr-1" />
                  In Watchlist
                </>
              ) : (
                <>
                  <Bookmark className="h-4 w-4 mr-1" />
                  Add to Watchlist
                </>
              )}
            </Button>
          </div>
        </DialogHeader>

        <ScrollArea className="max-h-[65vh] pr-4">
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-24 h-36 rounded-md bg-gradient-to-br from-purple-500/20 to-cyan-500/20 flex items-center justify-center shrink-0">
                <Film className="h-10 w-10 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0 space-y-3">
                <div className="flex items-center gap-3 flex-wrap">
                  <Badge variant="secondary" className="gap-1">
                    <Star className="h-3 w-3 text-amber-500" />
                    {movie.vote_average?.toFixed(1)} / 10
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    ({movie.vote_count?.toLocaleString()} votes)
                  </span>
                </div>
                
                <div className="flex items-center gap-4 flex-wrap text-sm text-muted-foreground">
                  {movie.release_date && (
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(movie.release_date).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </span>
                  )}
                  {movie.runtime > 0 && (
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {Math.floor(movie.runtime / 60)}h {movie.runtime % 60}m
                    </span>
                  )}
                </div>

                {movie.genres && (
                  <div className="flex flex-wrap gap-1.5">
                    {movie.genres.split(" ").map((genre) => (
                      <Badge key={genre} variant="outline">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                )}
                
                {movie.tagline && (
                  <p className="text-sm italic text-muted-foreground">
                    "{movie.tagline}"
                  </p>
                )}
              </div>
            </div>

            {movie.overview && (
              <div>
                <h4 className="font-semibold mb-2">Overview</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {movie.overview}
                </p>
              </div>
            )}

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1">
              {movie.director && (
                <DetailRow icon={Users} label="Director" value={movie.director} />
              )}
              {movie.cast && (
                <DetailRow 
                  icon={Users} 
                  label="Cast" 
                  value={movie.cast.split(" ").slice(0, 5).join(", ")} 
                />
              )}
              {formatCurrency(movie.budget) && (
                <DetailRow icon={DollarSign} label="Budget" value={formatCurrency(movie.budget)!} />
              )}
              {formatCurrency(movie.revenue) && (
                <DetailRow icon={DollarSign} label="Revenue" value={formatCurrency(movie.revenue)!} />
              )}
              <DetailRow icon={TrendingUp} label="Popularity" value={movie.popularity?.toFixed(1) || ""} />
              {movie.original_language && (
                <DetailRow icon={Languages} label="Original Language" value={movie.original_language.toUpperCase()} />
              )}
              {movie.production_companies && (
                <DetailRow 
                  icon={Building2} 
                  label="Production Companies" 
                  value={movie.production_companies.split(" ").slice(0, 3).join(", ")} 
                />
              )}
              {movie.production_countries && (
                <DetailRow 
                  icon={MapPin} 
                  label="Production Countries" 
                  value={movie.production_countries} 
                />
              )}
              {movie.status && (
                <DetailRow icon={Film} label="Status" value={movie.status} />
              )}
            </div>

            {movie.keywords && (
              <>
                <Separator />
                <div>
                  <h4 className="font-semibold mb-2">Keywords</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {movie.keywords.split(" ").slice(0, 10).map((keyword) => (
                      <Badge key={keyword} variant="secondary" className="text-xs">
                        {keyword.replace(/_/g, " ")}
                      </Badge>
                    ))}
                  </div>
                </div>
              </>
            )}

            {movie.homepage && (
              <>
                <Separator />
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-muted-foreground" />
                  <a
                    href={movie.homepage}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-primary hover:underline"
                  >
                    Official Website
                  </a>
                </div>
              </>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
